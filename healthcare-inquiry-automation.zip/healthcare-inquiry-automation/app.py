"""
Beacon Crest Health - AI Inquiry & Follow-up Hub  (Streamlit entry point / router)

Run:  streamlit run app.py
"""

import os

import streamlit as st

from ai_service import available_providers
from config import DEMO_NOTICE
from database import count_inquiries, init_db
from generate_demo_data import seed_synthetic_data
from ui_components import inject_css, render

st.set_page_config(page_title="Beacon Crest - Inquiry Hub", page_icon=":material/local_hospital:",
                   layout="wide", initial_sidebar_state="auto")


@st.cache_resource
def _bootstrap() -> bool:
    """Runs once per server process: creates/migrates the DB and (only if empty) loads synthetic demo rows."""
    init_db()
    if count_inquiries() == 0 and os.getenv("AUTO_SEED_DEMO", "1") == "1":
        seed_synthetic_data()
    return True


_bootstrap()
inject_css()
st.logo("assets/logo.svg", size="large")

pages = [
    st.Page("views/dashboard.py", title="Dashboard", icon=":material/space_dashboard:", default=True),
    st.Page("views/inquiries.py", title="Patient Inquiries", icon=":material/inbox:", url_path="inquiries"),
    st.Page("views/new_enquiry.py", title="New Enquiry", icon=":material/edit_square:", url_path="new-enquiry"),
    st.Page("views/classification.py", title="AI Classification", icon=":material/psychology:", url_path="ai-classification"),
    st.Page("views/followups.py", title="Follow-ups", icon=":material/outgoing_mail:", url_path="follow-ups"),
    st.Page("views/analytics.py", title="Analytics", icon=":material/monitoring:", url_path="analytics"),
    st.Page("views/settings.py", title="Settings", icon=":material/settings:", url_path="settings"),
]
nav = st.navigation(pages)

provider_labels = {"auto": "Auto (Gemini, then OpenAI, then rules)", "gemini": "Gemini only", "openai": "OpenAI only",
                   "offline": "Offline rules only"}
pref = st.session_state.get("ai_provider", "auto")
keys = available_providers(st.session_state.get("gemini_api_key"), st.session_state.get("openai_api_key"))
with st.sidebar:
    render(f'''<div class="side-card"><div class="side-label">AI engine</div>
      <b>{provider_labels.get(pref, pref)}</b><br>
      Gemini key: {"configured" if keys["gemini"] else "not set"}<br>OpenAI key: {"configured" if keys["openai"] else "not set"}</div>
      <div class="side-card"><div class="side-label">Delivery</div>Follow-up messages are <b>simulated</b>: logged, not sent.</div>
      <div class="side-card"><div class="side-label">Data</div>{DEMO_NOTICE}</div>''')

nav.run()
