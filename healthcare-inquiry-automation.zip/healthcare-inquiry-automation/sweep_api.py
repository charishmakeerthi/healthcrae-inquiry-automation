"""
Minimal HTTP endpoint so an external scheduler (n8n, cron, curl) can trigger the follow-up sweep.

    python sweep_api.py            # listens on 127.0.0.1:8502

Endpoints
    GET  /health                   -> {"status": "ok"}
    POST /api/followup/sweep       -> sweep summary JSON   (requires header  X-Sweep-Token)

Security
    * The token comes from the SWEEP_API_TOKEN environment variable. If it is not set the sweep
      endpoint refuses to run (503) - there is no default/guessable token.
    * Binds to 127.0.0.1 by default. Do not expose it publicly without TLS and a reverse proxy.
    * Standard library only (no extra dependency). Delivery is SIMULATED - see automation.py.
"""

import hmac
import json
import os
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from automation import sweep_summary_payload
from database import init_db

_SWEEP_LOCK = threading.Lock()


class SweepHandler(BaseHTTPRequestHandler):
    server_version = "FollowupSweep/1.0"

    def _send(self, code: int, payload: dict) -> None:
        body = json.dumps(payload).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):  # noqa: N802
        if self.path == "/health":
            self._send(200, {"status": "ok", "service": "followup-sweep-api"})
        else:
            self._send(404, {"error": "not_found"})

    def do_POST(self):  # noqa: N802
        if self.path != "/api/followup/sweep":
            return self._send(404, {"error": "not_found"})
        expected = os.getenv("SWEEP_API_TOKEN", "")
        if not expected:
            return self._send(503, {"error": "SWEEP_API_TOKEN is not configured on the server"})
        supplied = self.headers.get("X-Sweep-Token", "")
        if not hmac.compare_digest(supplied.encode(), expected.encode()):
            return self._send(401, {"error": "invalid_or_missing_token"})
        with _SWEEP_LOCK:
            try:
                self._send(200, sweep_summary_payload())
            except Exception as exc:  # never leak internals to the caller
                self._send(500, {"error": "sweep_failed", "type": type(exc).__name__})

    def log_message(self, fmt, *args):  # keep request logs terse, never log headers
        print(f"[sweep-api] {self.address_string()} {fmt % args}")


def make_server(host: str = "127.0.0.1", port: int = 8502) -> ThreadingHTTPServer:
    init_db()
    return ThreadingHTTPServer((host, port), SweepHandler)


if __name__ == "__main__":
    host = os.getenv("SWEEP_API_HOST", "127.0.0.1")
    port = int(os.getenv("SWEEP_API_PORT", "8502"))
    if not os.getenv("SWEEP_API_TOKEN"):
        print("WARNING: SWEEP_API_TOKEN is not set - POST /api/followup/sweep will return 503.")
    print(f"Follow-up sweep API on http://{host}:{port}  (GET /health, POST /api/followup/sweep)")
    make_server(host, port).serve_forever()
