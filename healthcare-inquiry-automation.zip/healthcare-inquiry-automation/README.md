# Beacon Crest Health - AI Inquiry & Follow-up Hub

An AI-assisted front-desk tool for a small clinic: it takes patient enquiries, **classifies** them, **drafts a safe, knowledge-grounded reply**, **escalates possible emergencies to a human**, and runs a **follow-up automation** so no enquiry is forgotten.

Built for the *AI Skills & Prompt Engineering Assessment* (category: **Automation**, domain: **Healthcare**).

> **Demo only.** The clinic ("Beacon Crest Community Health Center"), its doctors, fees, phone and address are **fictional placeholders**, and all patient records are **synthetic** (`example.com` addresses). Follow-up messages are **simulated** (logged, not sent). See [Limitations](#limitations).

![Dashboard](docs/screenshots/01-dashboard.png)

---

## Problem

Clinic front desks answer the same questions all day (booking, opening hours, services, fees) while the genuinely urgent message can be buried in the same inbox, and follow-ups depend on someone remembering.

## Solution

| Step | What the system does |
|---|---|
| 1. Intake | Validated enquiry form (name, email, category, message), saved to SQLite. |
| 2. Triage | AI classifies into **Appointment booking / Clinic timings / Available services / General enquiry / Other**, with a **confidence score**, an **urgency flag** and a **one-line rationale**. |
| 3. Reply | A short reply grounded **only** in an approved knowledge base. No diagnosis, no medicines or doses, no invented contacts. |
| 4. Escalation | Red-flag wording (chest pain, breathing trouble, stroke signs, self-harm...) marks the enquiry **Urgent**. The patient gets a fixed template pointing to **112** (India's emergency number); staff are alerted; automated reminders are **never** sent for urgent cases. |
| 5. Follow-up | A sweep finds due enquiries, applies a 24 h cooldown and a 3-attempt limit, writes an audit log, and flags records that need a human. Can be triggered from the UI or by **n8n**. |
| 6. Insight | Dashboard and Analytics computed from stored rows only. |

## Features

- **7 pages:** Dashboard, Patient Inquiries, New Enquiry, AI Classification (sandbox), Follow-ups, Analytics, Settings.
- **Three engines:** Gemini, OpenAI, and an **offline rule-based fallback** that always works (no key needed).
- **Safety enforced in code** (not just prompts): urgency = model OR rules; urgent replies are never model-written; reply guard blocks dosage / medicine advice / diagnosis wording / unapproved phone, email or hospital; model output is validated.
- **Atomic duplicate prevention** for follow-ups; retry ceiling; manual-follow-up escalation.
- **Security:** HTML-escaped output, `.env` for keys (git-ignored), token-protected sweep API, no keys in logs.
- **Responsive**, tested at 1440 / 900 / 390 px.

## Screenshots

| | |
|---|---|
| ![Inquiries](docs/screenshots/02-patient-inquiries.png) | ![Urgent triage](docs/screenshots/03-new-enquiry-urgent-result.png) |
| Patient Inquiries: filters, record inspector, status updates | New Enquiry: urgent case escalated, 112 instruction |
| ![Classification](docs/screenshots/04-ai-classification.png) | ![Follow-ups](docs/screenshots/05-follow-ups-after-sweep.png) |
| AI Classification sandbox with guard check | Follow-ups: sweep, audit log, "needs a human" |
| ![Analytics](docs/screenshots/06-analytics.png) | ![Mobile](docs/screenshots/09-mobile-dashboard.png) |
| Analytics from stored records | Mobile layout |

*Screenshots were taken with no API keys configured, so the engine shown is the offline rule-based fallback.*

## Architecture

```mermaid
flowchart LR
  U[Staff / Patient intake] --> S[Streamlit UI<br/>app.py + views/]
  S --> V[validation.py]
  S --> AI[ai_service.py]
  AI -->|key set| G[Gemini]
  AI -->|key set| O[OpenAI]
  AI -->|no key / error| R[Rule-based fallback]
  AI --> SAFE[Safety layer<br/>urgency OR, validation, reply guard]
  S --> DB[(SQLite<br/>database.py)]
  SAFE --> DB
  S --> A[automation.py<br/>sweep rules]
  N8N[n8n schedule] -->|POST + token| API[sweep_api.py]
  API --> A
  A --> DB
  A --> LOG[Audit table + outbox.log<br/>simulated delivery]
```

| File | Responsibility |
|---|---|
| `app.py` | Router, theme, sidebar status. |
| `views/*.py` | One module per page. |
| `ui_components.py` | Design system: tokens, CSS, escaped HTML helpers, charts. |
| `ai_service.py` | Prompts, providers, validation, urgency rules, reply guard. |
| `automation.py` | Eligibility rules and the follow-up sweep. |
| `database.py` | Schema, in-place migration, atomic claim, dashboard queries. |
| `sweep_api.py` | Tiny HTTP endpoint for n8n/cron (standard library only). |
| `validation.py` | Form validation. |
| `generate_demo_data.py` | Idempotent synthetic data, tagged `demo_seed`. |
| `config.py` | Categories, thresholds, **demo** knowledge base, emergency constant. |

## Quick start

**Requirements:** Python 3.10+ (tested on 3.12).

```powershell
# Windows PowerShell (macOS/Linux: python3 -m venv .venv && source .venv/bin/activate)
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt

copy .env.example .env        # then edit .env (optional - the app runs without keys)
streamlit run app.py
```

Open http://localhost:8501. On first start, an **empty** database is filled with 9 synthetic demo enquiries (disable with `AUTO_SEED_DEMO=0`).

### Environment (`.env`, never committed)

| Variable | Purpose |
|---|---|
| `GEMINI_API_KEY` | Enables live Gemini calls. |
| `OPENAI_API_KEY` | Enables live OpenAI calls. |
| `GEMINI_MODEL`, `OPENAI_MODEL` | Optional model overrides. |
| `SWEEP_API_TOKEN` | Required to use `sweep_api.py`; no default exists. |

Without keys the app uses the offline rule-based engine. **Settings > AI engine > Run engine test** shows which engine actually answered.

### Follow-up sweep and n8n (optional)

```powershell
$env:SWEEP_API_TOKEN = "<long random value>"
python sweep_api.py                       # http://127.0.0.1:8502  (GET /health, POST /api/followup/sweep)
```

1. In n8n, import `n8n_healthcare_followup_workflow.json`.
2. Create a **Header Auth** credential: name `X-Sweep-Token`, value = your token.
3. Create an **SMTP** credential and replace the `example.com` placeholder addresses. If n8n runs in Docker use `host.docker.internal` instead of `127.0.0.1`.

The sweep only **logs** reminders. Only the staff-summary e-mail in n8n can be a real e-mail, and only once you configure SMTP.

## Testing

```bash
python -m pytest -q          # 92 pass, 3 skipped (live-API tests need your keys)
```

Tests run against **temporary databases** and never touch `data/`.

### Verification status (honest)

| Area | Status | Evidence |
|---|---|---|
| Validation, DB persistence, status updates, migration of an older DB | **Tested** | pytest (incl. migration of a pre-existing 17-row DB: no rows lost) |
| Classification (rules), urgency detection, reply guard | **Tested** | pytest |
| Provider failure handling (rate limit, auth, timeout, bad JSON, missing key, no secret leak) | **Tested with mocks** | pytest |
| Follow-up rules, cooldown, retry ceiling, urgent exclusion, atomic duplicate prevention (8 concurrent threads) | **Tested** | pytest |
| Sweep API (401 / 503 / 200, idempotent) | **Tested** | pytest + real HTTP calls |
| 7 pages render (empty + seeded DB), form flows | **Tested** | Streamlit AppTest + real Chromium run |
| HTML-injection attempt | **Tested** | real browser: nothing executes, text shown literally |
| Layout at 1440 / 900 / 390 px | **Tested** | screenshots, 0 px horizontal overflow |
| **Live Gemini / OpenAI calls** | **Not tested** (no keys available in the build environment) | 3 skipped tests run automatically once keys are set |
| **n8n workflow import and run** | **Not tested** (no n8n instance) | JSON structure validated; endpoint contract tested over HTTP |
| **Real e-mail / SMS delivery** | **Not implemented** | delivery is simulated by design |
| Deployment / public URL | **Not done** | run locally |

## Limitations

- **Not a medical device.** It does not diagnose or advise; it routes administrative enquiries.
- **Simulated delivery.** No e-mail or SMS provider is connected.
- **English only.** Urgency keywords do not cover Hindi, Telugu or other languages; a keyword list cannot catch every emergency phrasing, and it deliberately over-triggers (e.g. "no chest pain" is also flagged).
- **Rule-based confidence is a heuristic**, not a calibrated probability.
- **No authentication / roles.** Anyone who can open the app can edit records. Add auth (and a real database, backups, audit retention, privacy review) before any real patient data.
- **Fictional knowledge base.** Replace `config.CLINIC_KNOWLEDGE_BASE` with clinic-approved facts. The emergency number 112 should be confirmed against your own clinic policy.
- Single-process SQLite; fine for a demo, not for many concurrent staff.

## Project layout

```
app.py  config.py  database.py  ai_service.py  automation.py  validation.py
sweep_api.py  generate_demo_data.py  ui_components.py
views/            # dashboard, inquiries, new_enquiry, classification, followups, analytics, settings
tests/            # isolated pytest suite
docs/             # screenshots, prompts, requirement mapping, final report, video script, checklist
scripts/          # cleanup_test_records.py (for DBs made by the old test suite)
n8n_healthcare_followup_workflow.json
```

## Documentation

[PROMPT_ENGINEERING.md](PROMPT_ENGINEERING.md) | [docs/REQUIREMENTS_MAPPING.md](docs/REQUIREMENTS_MAPPING.md) | [docs/VIDEO_SCRIPT.md](docs/VIDEO_SCRIPT.md) | [docs/SUBMISSION_CHECKLIST.md](docs/SUBMISSION_CHECKLIST.md) | [docs/FINAL_REPORT.md](docs/FINAL_REPORT.md)
