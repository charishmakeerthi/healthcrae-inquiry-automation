"""
SQLite persistence layer.

* Existing databases are upgraded in place (additive migration - no rows are dropped).
* Follow-up reminders are claimed atomically so two concurrent sweeps cannot send duplicates.
* Every dashboard number in the app is derived from queries in this module.
"""

import datetime
import secrets
import sqlite3
from contextlib import contextmanager
from typing import Any, Dict, List, Optional

import pandas as pd

import config
from config import (
    DEFAULT_FOLLOWUP_DAYS,
    ENQUIRY_STATUSES,
    FOLLOW_UP_STATUSES,
)

SOURCE_WEB = "web_form"
SOURCE_DEMO = "demo_seed"


# ------------------------------------------------------------------ connections
def _db_path() -> str:
    # Read the module attribute at call time so tests can point at a temporary database.
    return str(config.DB_PATH)


def get_connection() -> sqlite3.Connection:
    conn = sqlite3.connect(_db_path(), check_same_thread=False, timeout=15)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode = WAL;")
    conn.execute("PRAGMA foreign_keys = ON;")
    return conn


@contextmanager
def connect():
    """Commit-or-rollback context manager that always closes the connection."""
    conn = get_connection()
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def _now() -> datetime.datetime:
    return datetime.datetime.now()


# ------------------------------------------------------------------ schema
def init_db() -> None:
    with connect() as conn:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS inquiries (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                enquiry_id TEXT UNIQUE NOT NULL,
                patient_name TEXT NOT NULL,
                patient_email TEXT NOT NULL,
                original_category TEXT NOT NULL,
                ai_category TEXT NOT NULL,
                confidence REAL NOT NULL,
                explanation TEXT NOT NULL,
                is_urgent INTEGER NOT NULL DEFAULT 0,
                original_message TEXT NOT NULL,
                generated_response TEXT NOT NULL,
                submission_timestamp TEXT NOT NULL,
                enquiry_status TEXT NOT NULL DEFAULT 'Pending Review',
                follow_up_status TEXT NOT NULL DEFAULT 'Follow-up Required',
                follow_up_due_date TEXT NOT NULL,
                last_notification_sent_at TEXT,
                notification_count INTEGER NOT NULL DEFAULT 0,
                staff_notes TEXT DEFAULT '',
                updated_at TEXT NOT NULL
            );
            """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS notification_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                enquiry_id TEXT NOT NULL,
                recipient_email TEXT NOT NULL,
                notification_type TEXT NOT NULL,
                channel TEXT NOT NULL,
                subject TEXT NOT NULL,
                payload_preview TEXT NOT NULL,
                status TEXT NOT NULL,
                timestamp TEXT NOT NULL,
                FOREIGN KEY (enquiry_id) REFERENCES inquiries(enquiry_id) ON DELETE CASCADE
            );
            """
        )
        _migrate(conn)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_enquiry_status ON inquiries(enquiry_status);")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_follow_up ON inquiries(follow_up_status, follow_up_due_date);")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_is_urgent ON inquiries(is_urgent);")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_submission ON inquiries(submission_timestamp);")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_notif_enq ON notification_logs(enquiry_id);")


def _migrate(conn: sqlite3.Connection) -> None:
    """Additive, idempotent migration. Never deletes or rewrites existing enquiry content."""
    cols = {r["name"] for r in conn.execute("PRAGMA table_info(inquiries);")}
    if "source" not in cols:
        conn.execute(f"ALTER TABLE inquiries ADD COLUMN source TEXT NOT NULL DEFAULT '{SOURCE_WEB}';")
        # Rows created by the earlier demo seeder are tagged so they can be told apart from real submissions.
        conn.execute(
            f"UPDATE inquiries SET source = '{SOURCE_DEMO}' WHERE staff_notes LIKE 'Seeded synthetic record%';"
        )
    if "ai_engine" not in cols:
        conn.execute("ALTER TABLE inquiries ADD COLUMN ai_engine TEXT NOT NULL DEFAULT 'unknown';")
    if "safety_notes" not in cols:
        conn.execute("ALTER TABLE inquiries ADD COLUMN safety_notes TEXT NOT NULL DEFAULT '';")


def generate_enquiry_id() -> str:
    return f"ENQ-{_now().strftime('%Y%m%d%H%M%S')}-{secrets.token_hex(2).upper()}"


# ------------------------------------------------------------------ writes
def insert_inquiry(data: Dict[str, Any]) -> str:
    now = _now()
    enquiry_id = data.get("enquiry_id") or generate_enquiry_id()
    due_date = data.get("follow_up_due_date") or (
        now + datetime.timedelta(days=DEFAULT_FOLLOWUP_DAYS)
    ).strftime("%Y-%m-%d")
    confidence = max(0.0, min(1.0, float(data.get("confidence", 0.0))))

    with connect() as conn:
        conn.execute(
            """
            INSERT INTO inquiries (
                enquiry_id, patient_name, patient_email, original_category, ai_category,
                confidence, explanation, is_urgent, original_message, generated_response,
                submission_timestamp, enquiry_status, follow_up_status, follow_up_due_date,
                last_notification_sent_at, notification_count, staff_notes, updated_at,
                source, ai_engine, safety_notes
            ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            """,
            (
                enquiry_id,
                data["patient_name"].strip(),
                data["patient_email"].strip().lower(),
                data.get("original_category", "General enquiry"),
                data.get("ai_category", "General enquiry"),
                confidence,
                data.get("explanation", ""),
                1 if data.get("is_urgent") else 0,
                data["original_message"].strip(),
                data["generated_response"].strip(),
                data.get("submission_timestamp", now.isoformat()),
                data.get("enquiry_status", "Pending Review"),
                data.get("follow_up_status", "Follow-up Required"),
                due_date,
                data.get("last_notification_sent_at"),
                int(data.get("notification_count", 0)),
                data.get("staff_notes", ""),
                now.isoformat(),
                data.get("source", SOURCE_WEB),
                data.get("ai_engine", "unknown"),
                data.get("safety_notes", ""),
            ),
        )
    return enquiry_id


def find_recent_duplicate(email: str, message: str, minutes: int = 10) -> Optional[str]:
    """Guards against double-clicks / resubmits: same email + same message within N minutes."""
    cutoff = (_now() - datetime.timedelta(minutes=minutes)).isoformat()
    with connect() as conn:
        row = conn.execute(
            """SELECT enquiry_id FROM inquiries
               WHERE patient_email = ? AND original_message = ? AND submission_timestamp >= ?
               ORDER BY submission_timestamp DESC LIMIT 1""",
            (email.strip().lower(), message.strip(), cutoff),
        ).fetchone()
    return row["enquiry_id"] if row else None


def update_inquiry_status(enquiry_id: str, status: str, staff_notes: Optional[str] = None) -> bool:
    if status not in ENQUIRY_STATUSES:
        raise ValueError(f"Invalid enquiry status: {status!r}")
    with connect() as conn:
        if staff_notes is not None:
            cur = conn.execute(
                "UPDATE inquiries SET enquiry_status=?, staff_notes=?, updated_at=? WHERE enquiry_id=?",
                (status, staff_notes, _now().isoformat(), enquiry_id),
            )
        else:
            cur = conn.execute(
                "UPDATE inquiries SET enquiry_status=?, updated_at=? WHERE enquiry_id=?",
                (status, _now().isoformat(), enquiry_id),
            )
        return cur.rowcount > 0


def update_follow_up_status(enquiry_id: str, follow_up_status: str, staff_notes: Optional[str] = None) -> bool:
    if follow_up_status not in FOLLOW_UP_STATUSES:
        raise ValueError(f"Invalid follow-up status: {follow_up_status!r}")
    with connect() as conn:
        if staff_notes is not None:
            cur = conn.execute(
                "UPDATE inquiries SET follow_up_status=?, staff_notes=?, updated_at=? WHERE enquiry_id=?",
                (follow_up_status, staff_notes, _now().isoformat(), enquiry_id),
            )
        else:
            cur = conn.execute(
                "UPDATE inquiries SET follow_up_status=?, updated_at=? WHERE enquiry_id=?",
                (follow_up_status, _now().isoformat(), enquiry_id),
            )
        return cur.rowcount > 0


def update_record(enquiry_id: str, status: str, follow_up_status: str, staff_notes: str) -> bool:
    """Single-transaction save used by the staff action form."""
    if status not in ENQUIRY_STATUSES or follow_up_status not in FOLLOW_UP_STATUSES:
        raise ValueError("Invalid status value.")
    with connect() as conn:
        cur = conn.execute(
            """UPDATE inquiries SET enquiry_status=?, follow_up_status=?, staff_notes=?, updated_at=?
               WHERE enquiry_id=?""",
            (status, follow_up_status, staff_notes, _now().isoformat(), enquiry_id),
        )
        return cur.rowcount > 0


def dispatch_follow_up(
    enquiry_id: str,
    recipient_email: str,
    subject: str,
    payload_preview: str,
    notification_type: str = "Follow-up Reminder",
    channel: str = "Simulated outbox",
    status: str = "Simulated (not sent)",
    cooldown_hours: float = 24,
    max_attempts: Optional[int] = 3,
) -> Optional[int]:
    """
    Atomically claim a follow-up slot and write the audit log in ONE transaction.

    Returns the new log id, or None when the claim was rejected (cooldown still active,
    attempt ceiling reached, enquiry resolved/closed, or unknown id). Because the guard
    lives in the UPDATE's WHERE clause, two concurrent callers cannot both succeed.
    """
    now = _now()
    cutoff = (now - datetime.timedelta(hours=cooldown_hours)).isoformat()
    conn = get_connection()
    try:
        conn.execute("BEGIN IMMEDIATE;")
        cur = conn.execute(
            """
            UPDATE inquiries
               SET last_notification_sent_at = ?,
                   notification_count = notification_count + 1,
                   follow_up_status = CASE WHEN follow_up_status = 'Follow-up Required'
                                           THEN 'Follow-up Sent' ELSE follow_up_status END,
                   updated_at = ?
             WHERE enquiry_id = ?
               AND enquiry_status != 'Resolved'
               AND follow_up_status NOT IN ('Completed', 'Follow-up Not Needed')
               AND (last_notification_sent_at IS NULL OR last_notification_sent_at <= ?)
               AND (? IS NULL OR notification_count < ?)
            """,
            (now.isoformat(), now.isoformat(), enquiry_id, cutoff, max_attempts, max_attempts),
        )
        if cur.rowcount == 0:
            conn.rollback()
            return None
        log = conn.execute(
            """INSERT INTO notification_logs
               (enquiry_id, recipient_email, notification_type, channel, subject, payload_preview, status, timestamp)
               VALUES (?,?,?,?,?,?,?,?)""",
            (enquiry_id, recipient_email, notification_type, channel, subject, payload_preview, status, now.isoformat()),
        )
        conn.commit()
        log_id = log.lastrowid
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()

    _append_outbox_file(now, notification_type, enquiry_id, recipient_email, channel, status, subject, payload_preview)
    return log_id


def _append_outbox_file(now, ntype, enquiry_id, recipient, channel, status, subject, preview) -> None:
    try:
        with open(config.NOTIFICATIONS_LOG_PATH, "a", encoding="utf-8") as fh:
            fh.write(f"[{now.isoformat()}] [{ntype}] ID={enquiry_id} TO={recipient} CH={channel} STATUS={status}\n")
            fh.write(f"SUBJECT: {subject}\nPREVIEW: {preview}\n{'-' * 60}\n")
    except OSError:
        pass  # audit-file failure must not break the DB-backed workflow


# ------------------------------------------------------------------ reads
def get_inquiry(enquiry_id: str) -> Optional[Dict[str, Any]]:
    with connect() as conn:
        row = conn.execute("SELECT * FROM inquiries WHERE enquiry_id = ?", (enquiry_id,)).fetchone()
    return dict(row) if row else None


def get_all_inquiries_df() -> pd.DataFrame:
    with connect() as conn:
        return pd.read_sql_query("SELECT * FROM inquiries ORDER BY submission_timestamp DESC;", conn)


def get_notification_logs_df(enquiry_id: Optional[str] = None) -> pd.DataFrame:
    with connect() as conn:
        if enquiry_id:
            return pd.read_sql_query(
                "SELECT * FROM notification_logs WHERE enquiry_id = ? ORDER BY timestamp DESC;",
                conn, params=(enquiry_id,),
            )
        return pd.read_sql_query("SELECT * FROM notification_logs ORDER BY timestamp DESC;", conn)


def get_dashboard_summary() -> Dict[str, Any]:
    today = _now().strftime("%Y-%m-%d")
    with connect() as conn:
        def one(sql: str, params: tuple = ()) -> int:
            return conn.execute(sql, params).fetchone()[0] or 0

        open_follow = "enquiry_status != 'Resolved' AND follow_up_status = 'Follow-up Required'"
        return {
            "total_enquiries": one("SELECT COUNT(*) FROM inquiries"),
            "pending_enquiries": one("SELECT COUNT(*) FROM inquiries WHERE enquiry_status='Pending Review'"),
            "under_investigation": one("SELECT COUNT(*) FROM inquiries WHERE enquiry_status='Under Investigation'"),
            "resolved_enquiries": one("SELECT COUNT(*) FROM inquiries WHERE enquiry_status='Resolved'"),
            "urgent_flags": one("SELECT COUNT(*) FROM inquiries WHERE is_urgent=1"),
            "urgent_open": one("SELECT COUNT(*) FROM inquiries WHERE is_urgent=1 AND enquiry_status!='Resolved'"),
            "follow_ups_due": one(f"SELECT COUNT(*) FROM inquiries WHERE {open_follow} AND follow_up_due_date <= ? AND is_urgent=0", (today,)),
            "follow_ups_upcoming": one(f"SELECT COUNT(*) FROM inquiries WHERE {open_follow} AND follow_up_due_date > ? AND is_urgent=0", (today,)),
            "follow_ups_sent": one("SELECT COUNT(*) FROM inquiries WHERE follow_up_status='Follow-up Sent' AND enquiry_status!='Resolved'"),
            "follow_ups_manual": one("SELECT COUNT(*) FROM inquiries WHERE follow_up_status='Manual Follow-up Needed' AND enquiry_status!='Resolved'"),
            "follow_ups_completed": one("SELECT COUNT(*) FROM inquiries WHERE follow_up_status='Completed'"),
            "notifications_logged": one("SELECT COUNT(*) FROM notification_logs"),
            "demo_records": one("SELECT COUNT(*) FROM inquiries WHERE source=?", (SOURCE_DEMO,)),
            "avg_confidence": conn.execute("SELECT AVG(confidence) FROM inquiries").fetchone()[0],
        }


def get_recent_activity(limit: int = 8) -> List[Dict[str, str]]:
    """Real activity feed built only from stored rows (new enquiries + logged notifications)."""
    with connect() as conn:
        enq = conn.execute(
            "SELECT patient_name, ai_category, is_urgent, submission_timestamp AS ts FROM inquiries "
            "ORDER BY submission_timestamp DESC LIMIT ?", (limit,),
        ).fetchall()
        notes = conn.execute(
            "SELECT enquiry_id, notification_type, status, timestamp AS ts FROM notification_logs "
            "ORDER BY timestamp DESC LIMIT ?", (limit,),
        ).fetchall()
    items: List[Dict[str, str]] = []
    for r in enq:
        items.append({
            "ts": r["ts"],
            "kind": "urgent" if r["is_urgent"] else "enquiry",
            "text": f"{'Urgent enquiry' if r['is_urgent'] else 'New enquiry'} from {r['patient_name']} - {r['ai_category']}",
        })
    for r in notes:
        items.append({
            "ts": r["ts"],
            "kind": "notification",
            "text": f"{r['notification_type']} logged for {r['enquiry_id']}" + (" (simulated)" if str(r["status"]).startswith("Simulated") else f" ({r['status']})"),
        })
    items.sort(key=lambda x: x["ts"], reverse=True)
    return items[:limit]


# ------------------------------------------------------------------ maintenance
def count_inquiries() -> int:
    with connect() as conn:
        return conn.execute("SELECT COUNT(*) FROM inquiries").fetchone()[0]


def delete_demo_records() -> int:
    """Deletes ONLY rows tagged as demo seed data (notification logs cascade). Real rows are untouched."""
    with connect() as conn:
        cur = conn.execute("DELETE FROM inquiries WHERE source = ?", (SOURCE_DEMO,))
        return cur.rowcount
