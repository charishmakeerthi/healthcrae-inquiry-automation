"""
Synthetic demo data seeder.

All people, e-mail addresses and messages below are FICTIONAL (example.com addresses).
Seeded rows are tagged source='demo_seed' so they can be told apart from real submissions
and removed without touching anything else.

    python generate_demo_data.py            # seed only if no demo rows exist
    python generate_demo_data.py --reset    # delete demo rows only, then re-seed
"""

import datetime
import sys

from ai_service import process_inquiry_ai
from database import SOURCE_DEMO, connect, delete_demo_records, init_db, insert_inquiry

# days_ago: when it was submitted; due_in: follow-up due date relative to today
DEMO_ENQUIRIES = [
    ("Priya Sharma", "priya.sharma@example.com", "Appointment booking", 9, -6, "Resolved", "Completed",
     "Hello, I would like to book a routine health check with Dr. Anita Rao next week, preferably in the afternoon."),
    ("Rohan Mehta", "rohan.mehta@example.com", "Clinic timings", 8, -5, "Resolved", "Completed",
     "What are your working hours on Saturdays? Is the blood lab open at the same time?"),
    ("Ananya Reddy", "ananya.reddy@example.com", "Available services", 7, -4, "Resolved", "Completed",
     "Do you offer vaccinations for children and what is the approximate fee?"),
    ("Karthik Nair", "karthik.nair@example.com", "Appointment booking", 5, -2, "Pending Review", "Follow-up Required",
     "I need to reschedule my appointment with Dr. Suresh Kumar to a weekday morning. Is that possible?"),
    ("Sneha Pillai", "sneha.pillai@example.com", "Available services", 4, -1, "Under Investigation", "Follow-up Required",
     "Can you tell me whether you accept cashless insurance and what a basic lipid profile costs?"),
    ("Vikram Singh", "vikram.singh@example.com", "General enquiry", 3, 0, "Pending Review", "Follow-up Required",
     "Where exactly is the clinic located and is there parking available for visitors?"),
    ("Divya Menon", "divya.menon@example.com", "Clinic timings", 1, 1, "Pending Review", "Follow-up Required",
     "Are you open on Sundays? My father can only visit on weekends."),
    ("Arjun Das", "arjun.das@example.com", "General enquiry", 0, 0, "Pending Review", "Follow-up Required",
     "I have sudden crushing chest pain and shortness of breath right now. Can a doctor see me immediately?"),
    ("Meena Joseph", "meena.joseph@example.com", "Other", 2, 2, "Pending Review", "Follow-up Required",
     "Could you share the clinic's tie-up details with corporate wellness programs and their pricing?"),
]


def seed_synthetic_data(force_reseed: bool = False) -> int:
    """Seeds demo rows. Returns number inserted. Never touches rows that are not tagged as demo."""
    init_db()
    with connect() as conn:
        existing = conn.execute("SELECT COUNT(*) FROM inquiries WHERE source = ?", (SOURCE_DEMO,)).fetchone()[0]
    if existing and not force_reseed:
        return 0
    if existing and force_reseed:
        delete_demo_records()

    now = datetime.datetime.now()
    inserted = 0
    for name, email, user_cat, days_ago, due_in, status, fu_status, message in DEMO_ENQUIRIES:
        # provider="offline": deterministic, free, and never sends demo text to an external API
        cls, response = process_inquiry_ai(message, name, user_cat, provider="offline")
        submitted = (now - datetime.timedelta(days=days_ago, hours=(inserted * 3) % 7)).replace(microsecond=0)
        insert_inquiry({
            "patient_name": name, "patient_email": email, "original_category": user_cat,
            "ai_category": cls["category"], "confidence": cls["confidence"], "explanation": cls["explanation"],
            "is_urgent": cls["is_urgent"], "original_message": message, "generated_response": response,
            "submission_timestamp": submitted.isoformat(), "enquiry_status": status,
            "follow_up_status": fu_status,
            "follow_up_due_date": (now + datetime.timedelta(days=due_in)).strftime("%Y-%m-%d"),
            "staff_notes": "Seeded synthetic record for demonstration.", "source": SOURCE_DEMO,
            "ai_engine": cls["engine"], "safety_notes": ", ".join(cls.get("safety_notes", [])),
        })
        inserted += 1
    return inserted


if __name__ == "__main__":
    n = seed_synthetic_data(force_reseed="--reset" in sys.argv)
    print(f"Seeded {n} synthetic demo enquiries." if n else "Demo data already present - nothing to do (use --reset).")
