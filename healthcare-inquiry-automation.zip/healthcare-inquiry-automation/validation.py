"""Input validation for the public enquiry form (kept separate from the UI so it is unit-testable)."""

import re
from typing import Tuple

from config import CATEGORIES

# Pragmatic RFC-5322 subset: no consecutive dots, 2+ letter TLD, length-capped.
_EMAIL_RE = re.compile(r"^[A-Za-z0-9._%+\-]+@(?:[A-Za-z0-9\-]+\.)+[A-Za-z]{2,}$")
_CONTROL_RE = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")

MAX_NAME = 100
MIN_MESSAGE = 10
MAX_MESSAGE = 3000


def validate_enquiry_form(name: str, email: str, message: str, category: str = "General enquiry") -> Tuple[bool, str]:
    name = (name or "").strip()
    email = (email or "").strip()
    message = (message or "").strip()

    if len(name) < 2:
        return False, "Patient name is required (minimum 2 characters)."
    if len(name) > MAX_NAME:
        return False, f"Patient name is too long (maximum {MAX_NAME} characters)."
    if _CONTROL_RE.search(name) or _CONTROL_RE.search(message):
        return False, "Text contains unsupported control characters."
    if not email or len(email) > 254 or ".." in email or not _EMAIL_RE.match(email):
        return False, "Please enter a valid email address (e.g. patient@example.com)."
    if len(message) < MIN_MESSAGE:
        return False, f"Enquiry message is too short. Please provide at least {MIN_MESSAGE} characters."
    if len(message) > MAX_MESSAGE:
        return False, f"Enquiry message exceeds the maximum length ({MAX_MESSAGE:,} characters)."
    if category not in CATEGORIES:
        return False, "Please choose a valid enquiry category."
    return True, ""
