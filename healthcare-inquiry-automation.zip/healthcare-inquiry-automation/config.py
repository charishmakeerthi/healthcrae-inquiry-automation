"""
Configuration and approved knowledge base.

IMPORTANT: Every clinic detail below is SYNTHETIC DEMO CONTENT. It describes a fictional
clinic ("Beacon Crest Community Health Center") and must be replaced with verified,
clinic-approved information before any real-world use.
"""

import os
from pathlib import Path

try:  # optional: load a local .env (never committed; see .env.example)
    from dotenv import load_dotenv

    load_dotenv(Path(__file__).resolve().parent / ".env")
except Exception:  # pragma: no cover - dotenv is optional at runtime
    pass

# ---------------------------------------------------------------- paths
BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = Path(os.getenv("HEALTHCARE_DATA_DIR", BASE_DIR / "data"))
DATA_DIR.mkdir(parents=True, exist_ok=True)

DB_PATH = DATA_DIR / "healthcare_inquiries.db"
NOTIFICATIONS_LOG_PATH = DATA_DIR / "notifications_outbox.log"

# ---------------------------------------------------------------- app metadata
APP_TITLE = "Beacon Crest Health - AI Inquiry & Follow-up Hub"
DEMO_NOTICE = "Demo clinic and synthetic patient data only. No real patient information."

# ---------------------------------------------------------------- AI models (override via env)
GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")
OPENAI_MODEL = os.getenv("OPENAI_MODEL", "gpt-4o-mini")
AI_TIMEOUT_SECONDS = float(os.getenv("AI_TIMEOUT_SECONDS", "30"))

# ---------------------------------------------------------------- taxonomy
CATEGORIES = [
    "Appointment booking",
    "Clinic timings",
    "Available services",
    "General enquiry",
    "Other",
]

ENQUIRY_STATUSES = ["Pending Review", "Under Investigation", "Resolved"]

FOLLOW_UP_STATUSES = [
    "Follow-up Required",
    "Follow-up Sent",
    "Manual Follow-up Needed",
    "Follow-up Not Needed",
    "Completed",
]

# ---------------------------------------------------------------- follow-up automation rules
NOTIFICATION_COOLDOWN_HOURS = 24      # minimum gap between automated reminders
MAX_FOLLOWUP_ATTEMPTS = 3             # retry ceiling before a human must act
DEFAULT_FOLLOWUP_DAYS = 2             # new enquiries are due for follow-up after N days

# ---------------------------------------------------------------- emergency handling
# 112 is India's official single emergency number (Ministry of Home Affairs ERSS).
# Verify against your clinic's own policy before real-world use.
EMERGENCY_NUMBER = "112"
EMERGENCY_INSTRUCTION = (
    f"Please call {EMERGENCY_NUMBER} (India's emergency number) or go to your nearest "
    "hospital emergency department immediately."
)

# Whole-word / phrase red-flag indicators (English only - see README limitations).
URGENT_INDICATORS = [
    "chest pain", "crushing chest", "heart attack", "shortness of breath",
    "difficulty breathing", "trouble breathing", "can't breathe", "cannot breathe",
    "cant breathe", "not breathing", "stroke", "facial drooping", "face drooping",
    "slurred speech", "severe bleeding", "bleeding heavily", "won't stop bleeding",
    "unconscious", "unresponsive", "passed out", "fainted", "seizure", "convulsion",
    "anaphylaxis", "allergic shock", "swollen throat", "suicidal", "suicide",
    "kill myself", "end my life", "want to die", "self harm", "self-harm",
    "overdose", "poisoning", "swallowed poison", "severe burn", "head trauma",
    "head injury", "coughing blood", "vomiting blood", "snake bite",
]

# ---------------------------------------------------------------- approved knowledge base (DEMO)
CLINIC_KNOWLEDGE_BASE = {
    "clinic_name": "Beacon Crest Community Health Center",
    "demo_notice": "Fictional demo clinic. All details are placeholders.",
    "address": "Demo Address, Sample City, India (placeholder)",
    "phone": "+91 00000 00000 (placeholder)",
    "email": "support@example.com (placeholder)",
    "operating_hours": {
        "Monday - Friday": "9:00 AM - 6:00 PM",
        "Saturday": "9:00 AM - 1:00 PM",
        "Sunday": "Closed",
    },
    "practitioners": [
        {"name": "Dr. Anita Rao (demo)", "specialty": "Internal Medicine & Chronic Care"},
        {"name": "Dr. Suresh Kumar (demo)", "specialty": "Family Practice & Preventive Medicine"},
        {"name": "Dr. Meera Iyer (demo)", "specialty": "Pediatrics & Adolescent Health"},
        {"name": "Dr. Rahul Verma (demo)", "specialty": "Geriatric Medicine & Wellness"},
    ],
    "approved_services": [
        {
            "name": "General Consultation & Health Checks",
            "fee_range": "Rs. 400 - 800 (demo fee)",
            "description": "Routine checkups, physical exams, blood pressure screening and preventive counselling.",
        },
        {
            "name": "Pediatric Care & Vaccinations",
            "fee_range": "Rs. 300 - 700 (demo fee)",
            "description": "Well-child exams, childhood immunizations and developmental checkups.",
        },
        {
            "name": "Chronic Disease Management",
            "fee_range": "Rs. 500 - 1,000 (demo fee)",
            "description": "Ongoing monitoring for conditions such as hypertension, diabetes and asthma.",
        },
        {
            "name": "On-Site Diagnostic Blood Lab",
            "fee_range": "Rs. 150 - 1,500 depending on panel (demo fee)",
            "description": "Common panels such as lipid profile, CBC, HbA1c and thyroid tests. Fasting instructions provided.",
        },
        {
            "name": "Seasonal Vaccine Clinic",
            "fee_range": "Rs. 400 - 900 (demo fee)",
            "description": "Seasonal influenza and other approved vaccines for adults and adolescents.",
        },
    ],
    "payment_and_insurance": (
        "Self-pay and selected cashless insurance plans are supported (demo statement). "
        "The front desk confirms eligibility for a specific plan."
    ),
    "appointment_policy": {
        "booking_advance": "Appointments can be scheduled up to 30 days in advance.",
        "cancellation": "Please give at least 24 hours notice to reschedule or cancel.",
        "walk_ins": "Limited walk-in slots are available Monday to Friday, 9:00 AM - 11:00 AM, on a first-come basis.",
    },
    "telehealth_policy": "Virtual consultations are available for non-urgent follow-ups for existing patients.",
}
