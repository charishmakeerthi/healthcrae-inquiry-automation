# Requirement Mapping - Gokul Infocare "AI Skills & Prompt Engineering Assessment"

Source of truth: the assessment PDF. Status values: **Done**, **Done (needs your key)**, **You must do**.

## 1. The task

| PDF requirement | Existing implementation (before) | Missing / wrong (found in audit) | Final action | Verification |
|---|---|---|---|---|
| Create ONE project in Healthcare or Technology | Healthcare inquiry & follow-up system | - | Kept. Category chosen: **Automation** | README states category |
| Pick one area (Website / Marketing / Scraping / **Automation** / Innovation) | Automation workflow + web app | n8n workflow targeted a non-existent endpoint | Built `sweep_api.py`, rewrote workflow | HTTP tests: 401 / 503 / 200, idempotent |
| AI tools must play a **meaningful role** | Gemini/OpenAI classification + reply | Model output was trusted unchecked; safety only in prompt | Model output validated; safety enforced in code; offline fallback | 37 AI-service tests (mocked providers) |
| Related to healthcare/technology | Yes | Unsafe content: "911 / Springfield General Hospital" | Replaced with India's **112** (verified from official ERSS sources) + labelled demo data | Browser test: no "911"/"Springfield" anywhere |
| Show skills, creativity, problem-solving - not just an idea | Working app | UI broken (raw HTML in KPI cards, 897 px overflow), Settings page crashed | Rebuilt UI; fixed crash | Screenshots; AppTest of all 7 pages |

## 2. Deliverables

| PDF deliverable | Status | Where / what you must do |
|---|---|---|
| **1. Video, minimum 2 minutes**: AI tools, prompt engineering, approach (incl. prior experience), challenges, final outcome | **You must do** | Script + demo sequence ready: [`VIDEO_SCRIPT.md`](VIDEO_SCRIPT.md). Record it yourself. |
| **2. Prompt documentation**: all prompts + significant revisions | **Partly done - you must complete Stage 1** | [`PROMPT_ENGINEERING.md`](../PROMPT_ENGINEERING.md). Stage 2 prompts are recorded. I do **not** have your earlier prompts used to build the first version; paste them into the marked slot. |
| **3. Project link** (GitHub / live app / Drive / demo) | **You must do** | GitHub-ready folder provided. Create the repo (or Drive link) and verify it opens in a private/incognito window. |
| Instructions to run if not hosted | Done | README "Quick start" |
| Email to jobs@gokulinfocare.com; Drive link must be "anyone with the link" | **You must do** | See checklist |

## 3. "What we evaluate" -> evidence

| Criterion | Evidence in the project |
|---|---|
| Practical use of AI tools | Two LLM providers + offline fallback; AI in both classification and drafting |
| Prompt engineering & iterative improvement | PROMPT_ENGINEERING.md Section B3 (v1 -> v2 -> v2.1 with the observed reason for each change), injection-aware prompts |
| Creativity & innovation | Safety-by-construction (urgency OR, no model-written emergency replies, reply guard), atomic follow-up claim, escalation queue |
| Problem-solving & technical execution | 10 documented problems found and fixed with evidence (PROMPT_ENGINEERING.md Section C); 92 automated tests |
| Quality & usefulness | Real workflow (intake -> triage -> reply -> follow-up -> escalation), 7 polished, responsive pages |
| Ability to explain & demonstrate | Video script and demo sequence |

## 4. Functional modules (from your project brief)

| Module | Result |
|---|---|
| A. Enquiry management (form, validation, email, category, persistence, messages) | Done, tested (unit + browser) |
| B. Classification (5 categories, confidence, urgency, explanation, graceful errors) | Done; rules tested; live LLM **needs your key** |
| C. Safe replies (grounded, no diagnosis/prescription, human escalation, no fictional contacts) | Done, tested |
| D. Database (records, classification, statuses, notes, follow-ups, logs; preserve data) | Done; in-place migration verified on your real DB (17/17 rows kept) |
| E. Follow-up automation (schedule, due check, log, duplicates, retry limit, status, n8n) | Done; delivery **simulated**; n8n import **not tested** |
| F. Dashboard/analytics from real data | Done; test asserts dashboard numbers equal row counts |
