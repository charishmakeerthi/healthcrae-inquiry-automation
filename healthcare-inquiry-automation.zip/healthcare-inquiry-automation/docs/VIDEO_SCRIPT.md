# Video Presentation - script and recording plan

**Target length: 2:30 to 3:00** (the assessment requires at least 2 minutes). Speak naturally; the words below are a guide. **Fill every [BRACKET] with your real experience.** Do not claim anything you did not do.

## Before you record (10 minutes)
1. `streamlit run app.py` and open http://localhost:8501 in a clean browser window (zoom 100%, hide bookmarks bar).
2. Put a real key in `.env` **only if you want to show live AI**. Never show the `.env` file or the Settings key fields on screen. If you have no key, say so honestly and show the offline fallback.
3. Open `PROMPT_ENGINEERING.md` in a second tab.
4. Start a screen recorder (Windows: Win+Alt+R, or OBS / Loom). Record 1080p with your voice.

## Script with timings

**0:00-0:15 - Introduction**
"Hi, I'm [NAME]. For the Gokul Infocare assessment I built an AI-powered healthcare enquiry and follow-up automation, in the *Automation* category."

**0:15-0:35 - Problem and usefulness**
"Clinic front desks answer the same questions all day, an urgent message can get buried, and follow-ups depend on someone remembering. This tool classifies each enquiry, drafts a safe reply, escalates possible emergencies to a human, and runs the follow-ups."

**0:35-1:05 - AI tools and prompt engineering**
"At runtime it uses [Gemini / OpenAI - say which you actually tested], with an offline fallback so it never breaks. To build and harden it I used [LIST YOUR REAL TOOLS, e.g. Claude, Gemini, ChatGPT]. My prompts evolved: the first version trusted the model. After auditing I found a model could mark an emergency as non-urgent, so I moved safety into code: urgency is model OR keyword rules, emergency replies are never AI-written, and every AI reply passes a guard that blocks dosage, diagnosis wording and invented contacts. The prompt is a request; the code is the guarantee."

**1:05-1:20 - Architecture** *(show the diagram in the README)*
"Streamlit UI, SQLite database, an AI service with Gemini, OpenAI and rule-based fallback, a follow-up engine, and a small API so n8n can trigger the schedule."

**1:20-2:10 - Live demo** *(follow the demo sequence below)*

**2:10-2:35 - Challenges and problem-solving**
"Three real problems: first, I did not trust my earlier test results, so I re-checked and found the tests were writing into my live database, one page crashed, and the n8n workflow pointed at an endpoint that did not exist. I fixed all three and added 92 automated tests. Second, an emergency message used a US number and a fictional hospital; I replaced it with India's 112 and labelled all demo data. Third, my safety guard wrongly blocked fee ranges as phone numbers; the tests caught it and I fixed it."

**2:35-2:55 - Outcome and honesty**
"The result is a working, tested prototype. Honest limits: delivery is simulated, not real email; live API calls were [tested with my key / not tested]; and it needs authentication before real patient data. [ONE SENTENCE ABOUT HOW YOUR PREVIOUS EXPERIENCE INFLUENCED YOUR APPROACH - the PDF asks for this]. Thank you."

## Demo sequence (about 50 seconds on screen)

| Time | Page | Do this | Say |
|---|---|---|---|
| 1:20 | **Dashboard** | Point at the 4 KPI cards, trend, category chart, red urgent banner | "Every number comes from the database; this red banner is an open urgent case." |
| 1:30 | **New Enquiry** | Click **Routine booking**, then **Submit** | "Triage gives category, confidence, rationale and a grounded reply." |
| 1:40 | **New Enquiry** | Click **Urgent symptoms**, **Submit** | "Chest pain: flagged Urgent, no AI-written reply, patient told to call 112, staff alerted." |
| 1:50 | **AI Classification** | Pick **Medical advice request**, **Run triage** | "A request for tablets and doses: the guard check confirms no dosage or diagnosis." |
| 1:58 | **Follow-ups** | Click **Run sweep now**; point to "Needs a human" and the audit log | "Due enquiries are logged once; the urgent case is escalated, not auto-reminded. Running it again sends nothing new." |
| 2:05 | **Patient Inquiries** | Open the urgent record, show status update | "Staff update status and notes here." |

## Likely interview questions (short answers)
- **Why not trust the model's urgency?** "Missing an emergency is costly, so rules can only escalate, never downgrade."
- **What if the API is down or rate-limited?** "It falls back to rules, and the reason is recorded in the safety notes."
- **Is email really sent?** "No. Delivery is simulated and labelled; n8n with SMTP would send the staff summary."
- **What would you do next?** "Authentication, multilingual urgency detection, a real delivery provider, and clinician review of the knowledge base."
