# Prompt 1 - Audit, completion and UI redesign brief (condensed record)

> Given to Claude (Anthropic) at the start of the hardening stage.
> **This is a condensed record, not a character-for-character copy:** the original's bullet lists were joined onto fewer lines and some wording was shortened; every requirement and constraint was kept. For an exact copy, paste the original message from your own chat history over the block below.

```
# ROLE: SENIOR AI ENGINEER + FULL-STACK DEVELOPER + PREMIUM SAAS UI/UX DESIGNER

You are responsible for taking my existing AI Healthcare Inquiry and Follow-up Automation project from its current implementation stage to a complete, tested, professional, hiring-assessment-ready product.

This is a real hiring assessment for the position of AI Growth & Automation Associate at Gokul Infocare.

Your goal is not simply to generate code or improve the dashboard. Your goal is to complete the actual assessment requirements, verify the entire application, improve the product experience, and prepare all deliverables required for submission.

Act as an experienced engineering team working on a production-quality SaaS application.

# PHASE 1: UNDERSTAND THE ASSESSMENT AND EXISTING PROJECT
Before modifying anything:
1. Read the original hiring assessment document.
2. Understand every task, requirement and evaluation criterion.
3. Inspect my complete existing project folder.
4. Review all Python files, frontend files, database, configuration, prompts, tests and automation workflows.
5. Understand which features are already implemented.
6. Identify incomplete, broken, missing or poorly implemented functionality.
7. Identify security, reliability and usability issues.

Create a requirement-to-implementation checklist showing:
- Assessment requirement. - Existing implementation. - Missing work. - Required improvement. - Verification method.

Do not start unnecessary redesign before understanding the complete application.

# PHASE 2: COMPLETE ALL FUNCTIONAL REQUIREMENTS
Prioritize working functionality over visual appearance.
A. Patient Enquiry Management - form, input validation, email validation, category selection, secure submission, database persistence, clear success and error messages.
B. AI-Powered Enquiry Classification - use the existing Gemini and OpenAI integrations; appointment booking / clinic timings / available services / general enquiry / other; confidence score; urgency detection; explanation. Handle API errors, missing keys, invalid responses and rate limits gracefully.
C. AI Response Generation - based on approved FAQ information; relevant; avoid hallucinated clinic information; never provide medical diagnosis, prescriptions or treatment recommendations; escalate urgent or potentially dangerous enquiries to qualified human staff; do not use fictional emergency contacts or unverified hospital information.
D. Database Management - enquiry records, classification results, inquiry statuses, staff notes, follow-up records, notification logs. Ensure existing records are preserved.
E. Follow-up Automation - scheduling, due-date checking, notification logging, duplicate prevention, retry limits, status updates, n8n workflow integration. Do not claim that live email, SMS or scheduled automation works unless it has actually been configured and tested.
F. Dashboard and Analytics - all displayed metrics must come from actual database records. No fabricated metrics or fake success percentages.

# PHASE 3: PREMIUM UI/UX REDESIGN
Design inspiration: Linear, Stripe Dashboard, Vercel, shadcn/ui, modern healthcare administration platforms (quality and consistency principles, not copies).
Palette: Background #F7F9FC, Sidebar #14243A, Primary #2563EB, Main text #172B4D, Secondary text #64748B, Cards #FFFFFF, Borders #E5EAF1, Success #16A34A, Warning #D97706, Critical #DC2626.
Typography: Inter or equivalent, strong hierarchy, consistent weights.
Layout: 8px spacing system, controlled sidebar width, aligned cards, consistent component heights, professional tables, minimal shadows, subtle borders.
Dashboard: sidebar navigation, header with title and actions, four KPI cards, inquiry trend analytics, category donut chart, recent enquiry table, follow-up overview, recent activity (if supported by existing data).
Redesign every page: Dashboard, Patient inquiries, New enquiry, AI classification results, Follow-up management, Analytics, Settings.
Quality: alignment, spacing, icons, buttons, tables, forms, empty states, loading indicators, success/error notifications, responsive layout, no overlap, no horizontal overflow, no random CSS, no decorative clutter.
Use the existing Streamlit architecture unless there is a genuine technical reason to change it. Do not migrate to React or introduce another framework unnecessarily.

# PHASE 4: SECURITY AND CODE QUALITY
Review API key handling, environment variables, .env protection, .gitignore, database handling, input validation, error handling, logging, dependency versions. Never expose API keys in frontend code, GitHub, screenshots, logs, README or generated documentation. Do not print actual API key values during debugging. Use synthetic patient data only.

# PHASE 5: TESTING AND VERIFICATION
Run the complete existing test suite. Verify: application starts; enquiry form; input validation; AI classification with configured credentials; AI response generation; database persistence; dashboard metrics; status updates; follow-up scheduling; duplicate notification prevention; API failure fallback; all navigation pages; different screen sizes.
Fix errors rather than hiding them. Do not mark anything completed without testing it. Clearly distinguish: Tested successfully / Partially tested / Not tested / Requires external configuration.

# PHASE 6: HIRING ASSESSMENT DELIVERABLES
README (overview, problem, solution, features, stack, architecture, install, env config, run, test, screenshots, limitations); PROMPT_ENGINEERING.md (initial prompt, important follow-ups, revisions, AI tools used, why prompts changed, problems encountered, how prompts improved output, examples) - document actual prompts, do not invent development history; a 2-3 minute video presentation script and a short demo sequence; GitHub-ready project, requirements.txt, screenshots, final submission checklist. Do not claim a live deployment or public GitHub repository exists until it has been created and verified.

# PHASE 7: FINAL QUALITY REVIEW
Act as a strict technical hiring evaluator against: practical AI implementation, prompt engineering, creativity, technical execution, real-world usefulness, problem-solving, UI/UX, ability to explain, reliability and security, presentation. Identify weaknesses honestly and fix what can be fixed. Final report: completed features, modified/new files, test results, UI improvements, security improvements, remaining limitations, submission readiness, estimated completion percentage.

# EXECUTION RULES
1. Do not just provide suggestions - work on the existing codebase. 2. Inspect before editing. 3. Complete missing assessment requirements first. 4. Redesign the UI after functionality is stabilized. 5. Preserve working backend functionality. 6. Do not remove useful features. 7. Do not use fake data to make screenshots look impressive. 8. Do not expose API keys. 9. Test after every major change. 10. Work systematically until all feasible tasks are completed.
If something requires my permission, credentials, account access or manual action, tell me and continue with the remaining independent tasks. Do not stop after creating a plan. Execute the work.
```
