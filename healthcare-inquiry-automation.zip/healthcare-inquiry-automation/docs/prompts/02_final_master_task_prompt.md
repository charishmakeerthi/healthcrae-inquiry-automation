# Prompt 2 - "Final master task" (condensed record)

> Given to Claude after an initial UI redesign had been done. **Condensed record, not character-for-character**; every phase and constraint is kept. Paste the exact original from your chat history over this block if you want an exact copy.

```
# FINAL MASTER TASK: COMPLETE, AUDIT, POLISH AND PREPARE MY AI HEALTHCARE AUTOMATION PROJECT FOR HIRING SHORTLISTING

You are acting as my Senior AI Engineer, Full-Stack Developer, Product Designer, UI/UX Specialist, QA Engineer and Technical Hiring Assessment Evaluator.
I uploaded the original hiring assessment PDF from Gokul Infocare. I have also already implemented my project and completed an initial UI/UX redesign.
Take the EXISTING PROJECT to its final professional, fully tested, assessment-ready stage. Do not start from scratch.

PHASE 1: Read the assessment PDF (primary source of truth). Extract the task, categories, deliverables, AI tool requirements, prompt documentation, video, project link, evaluation criteria, submission instructions. Produce a mapping table: | Assessment Requirement | Existing Implementation | Missing Work | Final Action | Verification |. Do not add unrelated features.

PHASE 2: Inspect my existing project (AI-Powered Healthcare Inquiry & Follow-up Automation System; working directory "C:\ai agents"; app.py, ui_components.py, config.py, database.py, ai_service.py, automation.py, generate_demo_data.py, tests/, data/, requirements.txt, README.md, PROMPT_ENGINEERING.md, n8n workflow). My latest UI report states: seven portals, premium sidebar/dashboard, KPI cards and charts, inquiry management, intake, AI classification inspector, follow-up management, analytics, settings, nine tests passed, Streamlit HTTP 200. These are reported results - independently verify them. Preserve existing database records and working backend logic.

PHASE 3: Complete the assessment requirements - verify enquiry management, AI classification (5 categories, confidence, urgency, explanation), FAQ-grounded safe responses with human escalation, database persistence, automation (scheduling, due dates, duplicate prevention, retry limits, history, n8n), dashboard from real metrics. Fix broken features. No fake functionality; no claims about external integrations without evidence.

PHASE 4: Second-level premium UI/UX review (Linear / Stripe / Vercel / shadcn/ui as quality references). Keep the existing palette (#F7F9FC, #14243A, #2563EB, #172B4D, #64748B, #FFFFFF, #E5EAF1). Check: no excessive empty space, no inconsistent card heights, no random spacing, no oversized sidebar, no overlap, no decorative icons, no fake growth indicators, no fabricated statistics, no non-functional buttons, no horizontal overflow. Review every page individually and use screenshots/visual inspection - Python compilation succeeding is not proof of visual quality.

PHASE 5: Safety and security. The UI report mentions "Call 911 or visit Springfield General Hospital." - not appropriate for an Indian healthcare demo; replace fictional/country-inappropriate information with safe, clearly labelled demo content. For serious symptoms: no diagnosis, no medication, do not delay emergency care, escalate to qualified staff, use only verified local emergency information. Review .env handling, .gitignore, no hardcoded credentials, no secrets in logs/frontend/GitHub. Synthetic patient data only.

PHASE 6: Improve README.md and PROMPT_ENGINEERING.md (required sections listed; do not fabricate prompts, research, history or tool usage).

PHASE 7: Prepare a 2-3 minute video script covering introduction, problem, usefulness, AI tools, prompt engineering approach, architecture, live demo, challenges, outcome - simple enough for a fresher to explain to a technical interviewer - plus a demo sequence of pages and actions. Do not claim a video has been recorded.

PHASE 8: Final testing. Re-run the tests (previous report: 9 passed). Manually verify startup, navigation, enquiry submission, AI classification and response, persistence, status updates, follow-up automation, duplicate prevention, error handling, API failure fallback, responsive UI, all pages. Test Gemini and OpenAI separately when valid credentials exist. Report actual results, not expected results.

PHASE 9: GitHub and submission preparation - requirements.txt, README, PROMPT_ENGINEERING, .gitignore, source, tests, screenshots, n8n export. Do not upload .env, keys, credentials, real patient data or private database files. Do not claim deployment or publication until it has happened.

PHASE 10: Strict hiring-evaluator review against the PDF's criteria; fix feasible weaknesses; final report with requirement completion, features, modified/new files, test results, UI and security improvements, remaining manual tasks, GitHub/deployment status, video status, honest completion percentage, submission readiness.

STRICT EXECUTION: do not just recommend - inspect and modify the code; do not rewrite working backend logic unnecessarily; do not remove useful features; no fake demo results; no exposed credentials; do not skip testing; do not stop after a plan; complete phase by phase; tell me exactly what credentials or manual actions I must do and continue with independent work.

FIRST ACTION: read my uploaded assessment PDF, inspect the complete project, produce the requirement mapping, begin completing missing tasks.
```
