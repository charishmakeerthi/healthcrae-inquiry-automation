# Prompt 3 - Follow-up (verbatim, including original spelling)

```
i wnat based on this pdf do task and also give me best ui improve ui and do task
```

**Context:** this line was added at the end of the same message that carried the project zip and Prompt 2. It was sent after an earlier turn in which the project files were missing from the upload (the AI replied that it could not inspect or modify code it did not have, and asked for the zip and the real prompt history).
