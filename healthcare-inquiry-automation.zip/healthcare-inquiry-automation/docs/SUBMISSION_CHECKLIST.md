# Final Submission Checklist

Tick only what you have actually done and checked.

## A. Before publishing code
- [ ] `.env` is **not** in the folder you upload (only `.env.example`). Run `git status` and confirm.
- [ ] No API key anywhere: search the project for `AIza` and `sk-`. (`grep -r "AIza\|sk-" .` / PowerShell: `Select-String -Path * -Pattern "AIza|sk-" -Recurse`)
- [ ] `data/*.db` is not uploaded (the `.gitignore` already excludes it).
- [ ] The `.venv` folder is not uploaded (your original zip contained one; it is excluded).
- [ ] If you reuse your **old** database locally, optionally run `python scripts/cleanup_test_records.py` (dry run) to see legacy test rows left by the old test suite.

## B. Verify locally on your machine (things I could not do)
- [ ] `pip install -r requirements.txt` then `python -m pytest -q` (expect 92 passed, 3 skipped).
- [ ] Add a real key to `.env` and re-run pytest: the 3 skipped live tests should now run. Note the result honestly.
- [ ] Settings > AI engine > **Run engine test**: record whether Gemini and OpenAI each answered live.
- [ ] (Optional) Import the n8n workflow, set credentials, run once. If you did not, do not claim it works.

## C. Prompt documentation
- [ ] Paste your **real Stage 1 prompts** into `PROMPT_ENGINEERING.md` (Section A, Stage 1) - the assessment weighs this heavily.
- [ ] Delete `docs/prompts/ORIGINAL_PROMPT_ENGINEERING_unverified.md` or remove its unverified numbers if you reuse any of it.
- [ ] Update the "AI tools used" table with every tool you really used.

## D. Video (minimum 2 minutes)
- [ ] Recorded using `docs/VIDEO_SCRIPT.md`; covers tools, prompt engineering, approach (and prior experience), challenges, live demo, outcome.
- [ ] No keys, no `.env`, no real patient data on screen. Length at least 2:00.
- [ ] Uploaded (Drive/YouTube unlisted) and the link opens while logged out.

## E. Project link
- [ ] GitHub repo created, pushed, opened in an incognito window; **or** Drive folder set to "Anyone with the link" and opened while logged out.
- [ ] README renders and the screenshots show.

## F. Email
- [ ] To: jobs@gokulinfocare.com - includes (1) video link, (2) prompt documentation (file or link), (3) project link.
- [ ] If attachments are large, use a Drive link with access for anyone.

## Status as of this build
| Item | State |
|---|---|
| Code, UI, tests, docs | Done in this package |
| Live-key AI test | **Not done** (needs your key) |
| n8n import test | **Not done** |
| Stage 1 prompts | **Missing - yours to add** |
| Video | **Not recorded** |
| GitHub / deployment | **Not created** |
