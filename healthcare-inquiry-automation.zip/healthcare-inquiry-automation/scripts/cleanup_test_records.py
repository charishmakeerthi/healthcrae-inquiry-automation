"""
One-off helper for databases created by the ORIGINAL test suite, which wrote its fixtures into the live DB.

Dry run by default - it only LISTS matches. Add --apply to delete them (a timestamped backup copy is made first).
Only rows whose e-mail is one of the known test-fixture addresses are matched; nothing else is touched.

    python scripts/cleanup_test_records.py            # show what would be removed
    python scripts/cleanup_test_records.py --apply    # back up, then delete
"""
import shutil
import sqlite3
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
import config  # noqa: E402

TEST_EMAILS = ("alice.test@example.com", "persist@example.com", "workflow@example.com",
               "overdue@example.com", "future@example.com")

if not Path(config.DB_PATH).exists():
    sys.exit(f"No database at {config.DB_PATH}")
conn = sqlite3.connect(config.DB_PATH)
marks = ",".join("?" * len(TEST_EMAILS))
rows = conn.execute(f"SELECT enquiry_id, patient_name, patient_email FROM inquiries WHERE patient_email IN ({marks})", TEST_EMAILS).fetchall()
print(f"{len(rows)} legacy test-fixture row(s) found.")
for r in rows[:50]:
    print("  ", r)
if "--apply" in sys.argv and rows:
    backup = Path(config.DB_PATH).with_suffix(f".backup-{int(time.time())}.db")
    shutil.copy2(config.DB_PATH, backup)
    conn.execute("PRAGMA foreign_keys = ON;")
    conn.execute(f"DELETE FROM inquiries WHERE patient_email IN ({marks})", TEST_EMAILS)
    conn.commit()
    print(f"Deleted. Backup saved to {backup}")
elif rows:
    print("Dry run only. Re-run with --apply to delete.")
