"""
Design system for the Streamlit UI.

Principles
  * All user-supplied text is HTML-escaped before it is placed in markup (see `esc`).
  * HTML snippets are flattened (`h`) so Markdown never mistakes indented markup for a code block.
  * Cards around widgets/charts use native `st.container(border=True)`, styled via CSS.
  * 8px spacing scale, one font stack, one set of colour tokens.
"""

import datetime
import html as _html
import re
from typing import Any, Dict, Iterable, List, Optional

import altair as alt
import pandas as pd
import streamlit as st

PALETTE = {
    "bg": "#F7F9FC", "sidebar": "#14243A", "primary": "#2563EB", "primary_dark": "#1D4ED8",
    "primary_soft": "#EFF6FF", "text": "#172B4D", "muted": "#64748B", "card": "#FFFFFF",
    "border": "#E5EAF1", "success": "#16A34A", "success_soft": "#DCFCE7", "warning": "#B45309",
    "warning_soft": "#FEF3C7", "critical": "#DC2626", "critical_soft": "#FEE2E2", "neutral_soft": "#F1F5F9",
}
CATEGORY_COLORS = {
    "Appointment booking": "#2563EB", "Clinic timings": "#0EA5E9", "Available services": "#16A34A",
    "General enquiry": "#8B5CF6", "Other": "#64748B",
}

# Lucide-style inline icons (stroke = currentColor) - one consistent icon family.
_ICON_PATHS = {
    "inbox": '<path d="M22 12h-6l-2 3h-4l-2-3H2"/><path d="M5.45 5.11 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z"/>',
    "clock": '<circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/>',
    "check": '<path d="M20 6 9 17l-5-5"/>',
    "alert": '<path d="m21.73 18-8-14a2 2 0 0 0-3.46 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3"/><path d="M12 9v4"/><path d="M12 17h.01"/>',
    "send": '<path d="m22 2-7 20-4-9-9-4Z"/><path d="M22 2 11 13"/>',
    "calendar": '<rect width="18" height="18" x="3" y="4" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/>',
    "user": '<path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',
    "shield": '<path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"/>',
    "activity": '<path d="M22 12h-4l-3 9L9 3l-3 9H2"/>',
    "phone": '<path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.8 19.8 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.12 4.18 2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.13.96.36 1.9.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.91.34 1.85.57 2.81.7A2 2 0 0 1 22 16.92z"/>',
    "inbox2": '<rect width="18" height="14" x="3" y="5" rx="2"/><path d="m3 7 9 6 9-6"/>',
}


def icon(name: str, size: int = 18) -> str:
    return (f'<svg xmlns="http://www.w3.org/2000/svg" width="{size}" height="{size}" viewBox="0 0 24 24" fill="none" '
            f'stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">{_ICON_PATHS[name]}</svg>')


# ------------------------------------------------------------------ safe HTML helpers
def esc(value: Any) -> str:
    """Escape any user-supplied value for inclusion in HTML."""
    return _html.escape("" if value is None else str(value), quote=True)


def esc_multiline(value: Any) -> str:
    return esc(value).replace("\n", "<br>")


def h(markup: str) -> str:
    """Flatten markup: strips newlines/indentation so Markdown cannot treat it as a code block."""
    return re.sub(r"\s*\n\s*", "", markup.strip())


def render(markup: str) -> None:
    st.markdown(h(markup), unsafe_allow_html=True)


def spacer(px: int = 16) -> None:
    render(f'<div style="height:{px}px"></div>')


# ------------------------------------------------------------------ CSS
def inject_css() -> None:
    p = PALETTE
    st.markdown(f"""<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
html, body, .stApp, [data-testid="stAppViewContainer"], button, input, textarea, select {{
  font-family: 'Inter', 'Segoe UI', -apple-system, system-ui, sans-serif !important; color:{p['text']}; }}
.stApp {{ background:{p['bg']}; }}
header[data-testid="stHeader"] {{ background:transparent; height:2.5rem; }}
[data-testid="stDeployButton"], #MainMenu, footer {{ display:none !important; }}
.block-container {{ max-width:1240px; padding:1.5rem 2rem 3rem 2rem; }}
h1,h2,h3,h4 {{ color:{p['text']}; letter-spacing:-0.01em; }}

/* sidebar */
section[data-testid="stSidebar"] {{ background:{p['sidebar']}; width:264px !important; min-width:264px !important; }}
section[data-testid="stSidebar"] * {{ color:#CBD5E1; }}
section[data-testid="stSidebar"] [data-testid="stSidebarNavLink"] {{ border-radius:8px; padding:8px 12px; margin:2px 0; font-weight:500; font-size:0.92rem; }}
section[data-testid="stSidebar"] [data-testid="stSidebarNavLink"]:hover {{ background:rgba(255,255,255,0.08); }}
section[data-testid="stSidebar"] [data-testid="stSidebarNavLink"][aria-current="page"] {{ background:{p['primary']}; }}
section[data-testid="stSidebar"] [data-testid="stSidebarNavLink"][aria-current="page"] * {{ color:#FFFFFF !important; }}
section[data-testid="stSidebar"] hr {{ border-color:rgba(255,255,255,0.12); }}
.side-card {{ background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.08); border-radius:10px; padding:12px; margin-top:8px; font-size:0.8rem; line-height:1.5; }}
.side-card b {{ color:#F1F5F9; }}
.side-label {{ font-size:0.68rem; font-weight:600; letter-spacing:0.06em; text-transform:uppercase; color:#94A3B8 !important; margin-bottom:6px; }}

/* cards: native bordered containers */
[data-testid="stVerticalBlockBorderWrapper"] {{ background:{p['card']}; border:1px solid {p['border']} !important; border-radius:12px !important; box-shadow:0 1px 2px rgba(16,24,40,0.04); }}
[data-testid="stVerticalBlockBorderWrapper"] [data-testid="stVerticalBlockBorderWrapper"] {{ box-shadow:none; }}
[data-testid="stForm"] {{ border:1px solid {p['border']}; border-radius:12px; background:{p['card']}; padding:20px; }}

/* buttons */
.stButton > button, .stDownloadButton > button, [data-testid="stFormSubmitButton"] > button {{
  border-radius:8px; font-weight:600; font-size:0.875rem; min-height:40px; border:1px solid {p['border']}; background:#fff; color:{p['text']}; transition:background .15s,border-color .15s; }}
.stButton > button:hover, .stDownloadButton > button:hover, [data-testid="stFormSubmitButton"] > button:hover {{ border-color:#CBD5E1; background:#F8FAFC; color:{p['text']}; }}
.stButton > button[kind="primary"], [data-testid="stFormSubmitButton"] > button[kind="primaryFormSubmit"], [data-testid="stFormSubmitButton"] > button[kind="primary"] {{
  background:{p['primary']}; border-color:{p['primary']}; color:#fff; }}
.stButton > button[kind="primary"]:hover, [data-testid="stFormSubmitButton"] > button[kind="primary"]:hover {{ background:{p['primary_dark']}; border-color:{p['primary_dark']}; color:#fff; }}
.stButton > button:disabled {{ opacity:.5; }}
.stButton > button:focus-visible, input:focus-visible {{ outline:2px solid {p['primary']}; outline-offset:2px; }}

/* inputs */
[data-baseweb="input"], [data-baseweb="textarea"], [data-baseweb="select"] > div {{ border-radius:8px !important; background:#fff !important; border-color:{p['border']} !important; }}
label p, [data-testid="stWidgetLabel"] p {{ font-size:0.82rem !important; font-weight:600 !important; color:{p['text']} !important; }}

/* tabs */
.stTabs [data-baseweb="tab-list"] {{ gap:4px; border-bottom:1px solid {p['border']}; }}
.stTabs [data-baseweb="tab"] {{ height:40px; padding:0 14px; font-weight:600; font-size:0.875rem; color:{p['muted']}; }}
.stTabs [aria-selected="true"] {{ color:{p['primary']}; }}

/* custom components */
.pg-head {{ display:flex; justify-content:space-between; align-items:flex-end; gap:16px; margin:0 0 24px 0; }}
.pg-title {{ font-size:1.6rem !important; font-weight:700; margin:0 !important; padding:0 !important; line-height:1.2; }}
.pg-sub {{ font-size:0.9rem; color:{p['muted']}; margin:4px 0 0 0; }}
.kpi {{ background:{p['card']}; border:1px solid {p['border']}; border-radius:12px; padding:16px 20px; box-shadow:0 1px 2px rgba(16,24,40,0.04); height:132px; display:flex; flex-direction:column; justify-content:space-between; box-sizing:border-box; }}
.kpi-top {{ display:flex; justify-content:space-between; align-items:center; }}
.kpi-label {{ font-size:0.78rem; font-weight:600; color:{p['muted']}; text-transform:uppercase; letter-spacing:0.05em; }}
.kpi-icon {{ width:32px; height:32px; border-radius:8px; display:flex; align-items:center; justify-content:center; }}
.kpi-value {{ font-size:2rem; font-weight:700; line-height:1; letter-spacing:-0.02em; }}
.kpi-sub {{ font-size:0.78rem; color:{p['muted']}; }}
.card-title {{ font-size:0.95rem; font-weight:700; margin:0; }}
.card-sub {{ font-size:0.78rem; color:{p['muted']}; margin:2px 0 0 0; }}
.card-head {{ display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:8px; gap:12px; }}
.pill {{ display:inline-flex; align-items:center; gap:4px; padding:2px 10px; border-radius:9999px; font-size:0.75rem; font-weight:600; white-space:nowrap; line-height:1.6; }}
.pill-neutral {{ background:{p['neutral_soft']}; color:#475569; }} .pill-primary {{ background:{p['primary_soft']}; color:{p['primary_dark']}; }}
.pill-success {{ background:{p['success_soft']}; color:#15803D; }} .pill-warning {{ background:{p['warning_soft']}; color:{p['warning']}; }}
.pill-critical {{ background:{p['critical_soft']}; color:#B91C1C; }}
.tbl-wrap {{ overflow-x:auto; }}
table.tbl {{ width:100%; border-collapse:collapse; font-size:0.84rem; border:none !important; }} table.tbl th, table.tbl td {{ border-left:none !important; border-right:none !important; border-top:none !important; }} table.tbl td .sub {{ white-space:nowrap; font-size:0.72rem; }} table.tbl td:last-child {{ white-space:nowrap; }}
table.tbl th {{ text-align:left; font-size:0.72rem; font-weight:600; text-transform:uppercase; letter-spacing:0.05em; color:{p['muted']}; padding:8px 12px; border-bottom:1px solid {p['border']}; white-space:nowrap; }}
table.tbl td {{ padding:10px 12px; border-bottom:1px solid #F1F5F9; vertical-align:middle; }}
table.tbl tr:last-child td {{ border-bottom:none; }} .tbl .sub {{ color:{p['muted']}; font-size:0.76rem; }}
.stat-row {{ display:flex; justify-content:space-between; align-items:center; padding:10px 0; border-bottom:1px solid #F1F5F9; font-size:0.86rem; }}
.stat-row:last-child {{ border-bottom:none; }} .stat-row b {{ font-size:1rem; }}
.feed-item {{ display:flex; gap:12px; padding:10px 0; border-bottom:1px solid #F1F5F9; font-size:0.84rem; align-items:flex-start; }}
.feed-item:last-child {{ border-bottom:none; }}
.dot {{ width:8px; height:8px; border-radius:50%; margin-top:6px; flex:none; }}
.feed-time {{ color:{p['muted']}; font-size:0.74rem; }}
.banner {{ border-radius:10px; padding:12px 16px; font-size:0.86rem; display:flex; gap:12px; align-items:flex-start; margin-bottom:16px; line-height:1.5; }}
.banner-critical {{ background:{p['critical_soft']}; border:1px solid #FCA5A5; color:#7F1D1D; }}
.banner-info {{ background:{p['primary_soft']}; border:1px solid #BFDBFE; color:#1E3A8A; }}
.banner-success {{ background:{p['success_soft']}; border:1px solid #86EFAC; color:#14532D; }}
.banner-warning {{ background:{p['warning_soft']}; border:1px solid #FCD34D; color:#78350F; }}
.textbox {{ background:#F8FAFC; border:1px solid {p['border']}; border-radius:8px; padding:12px 14px; font-size:0.88rem; line-height:1.6; white-space:normal; word-break:break-word; }}
.field-label {{ font-size:0.72rem; font-weight:600; text-transform:uppercase; letter-spacing:0.05em; color:{p['muted']}; margin:12px 0 4px 0; }}
.empty {{ text-align:center; padding:32px 16px; color:{p['muted']}; font-size:0.88rem; }} .empty b {{ display:block; color:{p['text']}; font-size:0.95rem; margin-bottom:4px; }}
.meter {{ background:#E2E8F0; border-radius:9999px; height:8px; overflow:hidden; }} .meter > div {{ background:{p['primary']}; height:8px; }}

/* responsive: wrap column rows on narrower screens, never scroll the page sideways */
@media (max-width: 1100px) {{ [data-testid="stHorizontalBlock"] {{ flex-wrap:wrap; gap:16px; }} [data-testid="stColumn"] {{ min-width:calc(50% - 16px) !important; }} }}
@media (max-width: 640px) {{ .block-container {{ padding:3.5rem 1rem 2rem 1rem; }} [data-testid="stColumn"] {{ min-width:100% !important; }} .pg-head {{ flex-direction:column; align-items:flex-start; }} .pg-title {{ font-size:1.3rem; }} }}
</style>""", unsafe_allow_html=True)


# ------------------------------------------------------------------ components
def page_header(title: str, subtitle: str) -> None:
    render(f'<div class="pg-head"><div><h1 class="pg-title">{esc(title)}</h1><div class="pg-sub">{esc(subtitle)}</div></div></div>')


def card_header(title: str, subtitle: str = "", right: str = "") -> None:
    sub = f'<div class="card-sub">{esc(subtitle)}</div>' if subtitle else ""
    render(f'<div class="card-head"><div><div class="card-title">{esc(title)}</div>{sub}</div>{right}</div>')


def kpi_card(label: str, value: Any, icon_name: str, tone: str, sub: str = "") -> None:
    colors = {"primary": ("#EFF6FF", PALETTE["primary"]), "warning": ("#FEF3C7", PALETTE["warning"]),
              "success": ("#DCFCE7", PALETTE["success"]), "critical": ("#FEE2E2", PALETTE["critical"]),
              "neutral": ("#F1F5F9", "#475569")}
    bg, fg = colors[tone]
    render(f'''<div class="kpi"><div class="kpi-top"><span class="kpi-label">{esc(label)}</span>
      <span class="kpi-icon" style="background:{bg};color:{fg}">{icon(icon_name, 18)}</span></div>
      <div class="kpi-value">{esc(value)}</div><div class="kpi-sub">{esc(sub)}</div></div>''')


_TONES = {
    "Resolved": "success", "Completed": "success", "Pending Review": "warning", "Follow-up Required": "warning",
    "Under Investigation": "primary", "Follow-up Sent": "primary", "Manual Follow-up Needed": "critical",
    "Urgent": "critical", "Follow-up Not Needed": "neutral", "Normal": "neutral",
}


def pill(text: str, tone: Optional[str] = None) -> str:
    return f'<span class="pill pill-{tone or _TONES.get(text, "neutral")}">{esc(text)}</span>'


def banner(kind: str, text_html: str, icon_name: str = "alert") -> None:
    render(f'<div class="banner banner-{kind}"><span style="flex:none;margin-top:1px">{icon(icon_name, 18)}</span><div>{text_html}</div></div>')


def empty_state(title: str, text: str) -> None:
    render(f'<div class="empty"><b>{esc(title)}</b>{esc(text)}</div>')


def fmt_ts(ts: str) -> str:
    try:
        return datetime.datetime.fromisoformat(ts).strftime("%d %b, %H:%M")
    except (ValueError, TypeError):
        return esc(ts)


def inquiries_table(df: pd.DataFrame) -> str:
    """Compact HTML table with status pills (rows are escaped)."""
    rows = []
    for r in df.itertuples():
        urgent = pill("Urgent") if r.is_urgent else pill("Normal")
        rows.append(
            f'<tr><td><b>{esc(r.patient_name)}</b><div class="sub">{esc(r.enquiry_id)}</div></td>'
            f'<td>{esc(r.ai_category)}</td><td>{urgent}</td><td>{pill(r.enquiry_status)}</td>'
            f'<td>{pill(r.follow_up_status)}</td><td class="sub">{fmt_ts(r.submission_timestamp)}</td></tr>')
    head = "".join(f"<th>{c}</th>" for c in ("Patient", "Category", "Priority", "Status", "Follow-up", "Submitted"))
    return h(f'<div class="tbl-wrap"><table class="tbl"><thead><tr>{head}</tr></thead><tbody>{"".join(rows)}</tbody></table></div>')


# ------------------------------------------------------------------ charts
def _style(chart: alt.Chart, height: int) -> alt.Chart:
    return (chart.properties(height=height, background="transparent")
            .configure_view(strokeWidth=0)
            .configure_axis(labelFont="Inter", titleFont="Inter", labelColor=PALETTE["muted"], titleColor=PALETTE["muted"],
                            gridColor="#EEF2F7", domainColor="#E5EAF1", tickColor="#E5EAF1", labelFontSize=11, titleFontSize=11)
            .configure_legend(labelFont="Inter", labelColor=PALETTE["text"], labelFontSize=11, symbolType="circle"))


def daily_counts(df: pd.DataFrame, days: int = 14) -> pd.DataFrame:
    """Real counts per calendar day (zero-filled) from stored submission timestamps."""
    today = pd.Timestamp.now().normalize()
    idx = pd.date_range(end=today, periods=days, freq="D")
    s = pd.to_datetime(df["submission_timestamp"], errors="coerce").dt.normalize().value_counts()
    return pd.DataFrame({"Day": idx, "Enquiries": [int(s.get(d, 0)) for d in idx]})


def trend_chart(df: pd.DataFrame, days: int = 14, height: int = 240) -> alt.Chart:
    data = daily_counts(df, days)
    c = alt.Chart(data).mark_bar(color=PALETTE["primary"], cornerRadiusTopLeft=4, cornerRadiusTopRight=4, size=18).encode(
        x=alt.X("Day:T", title=None, axis=alt.Axis(format="%d %b", labelAngle=0, tickCount=min(days, 7))),
        y=alt.Y("Enquiries:Q", title=None, axis=alt.Axis(tickMinStep=1, format="d")),
        tooltip=[alt.Tooltip("Day:T", format="%d %b %Y"), alt.Tooltip("Enquiries:Q")])
    return _style(c, height)


def donut_chart(df: pd.DataFrame, height: int = 240) -> alt.Chart:
    counts = df["ai_category"].value_counts().rename_axis("Category").reset_index(name="Total")
    cats = list(CATEGORY_COLORS)
    c = alt.Chart(counts).mark_arc(innerRadius=50, outerRadius=80, cornerRadius=3, padAngle=0.02).encode(
        theta=alt.Theta("Total:Q"),
        color=alt.Color("Category:N", scale=alt.Scale(domain=cats, range=[CATEGORY_COLORS[k] for k in cats]),
                        legend=alt.Legend(orient="bottom", title=None, columns=2)),
        tooltip=["Category:N", "Total:Q"])
    return _style(c, height)


def bar_chart(data: pd.DataFrame, x: str, y: str, color: str = PALETTE["primary"], height: int = 220, horizontal: bool = True) -> alt.Chart:
    if horizontal:
        enc = dict(y=alt.Y(f"{x}:N", title=None, sort="-x", axis=alt.Axis(labelLimit=200)), x=alt.X(f"{y}:Q", title=None, axis=alt.Axis(tickMinStep=1, format="d")))
    else:
        enc = dict(x=alt.X(f"{x}:N", title=None), y=alt.Y(f"{y}:Q", title=None, axis=alt.Axis(tickMinStep=1, format="d")))
    c = alt.Chart(data).mark_bar(color=color, cornerRadiusEnd=4, size=18).encode(tooltip=[x, y], **enc)
    return _style(c, height)


# ------------------------------------------------------------------ flash messages (survive st.rerun)
def flash(message: str, kind: str = "success") -> None:
    st.session_state["_flash"] = (kind, message)


def show_flash() -> None:
    item = st.session_state.pop("_flash", None)
    if item:
        kind, message = item
        banner(kind, esc(message), "check" if kind == "success" else "alert")
