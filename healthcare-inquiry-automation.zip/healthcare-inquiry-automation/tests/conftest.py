"""Test isolation: every test gets its own throw-away SQLite file. Tests NEVER touch data/healthcare_inquiries.db."""
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

import config  # noqa: E402
import database  # noqa: E402


@pytest.fixture(autouse=True)
def isolated_env(tmp_path, monkeypatch):
    monkeypatch.setattr(config, "DB_PATH", tmp_path / "test.db")
    monkeypatch.setattr(config, "NOTIFICATIONS_LOG_PATH", tmp_path / "outbox.log")
    for k in ("GEMINI_API_KEY", "GOOGLE_API_KEY", "OPENAI_API_KEY", "SWEEP_API_TOKEN"):
        monkeypatch.delenv(k, raising=False)
    database.init_db()
    yield


def make_record(**over):
    import datetime
    base = dict(patient_name="Test Person", patient_email="t@example.com", original_category="General enquiry",
                ai_category="General enquiry", confidence=0.8, explanation="x", is_urgent=False,
                original_message="A reasonably long test message.", generated_response="reply",
                follow_up_due_date=(datetime.datetime.now() - datetime.timedelta(days=1)).strftime("%Y-%m-%d"))
    base.update(over)
    return database.insert_inquiry(base)
