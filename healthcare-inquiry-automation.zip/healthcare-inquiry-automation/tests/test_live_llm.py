"""Live provider tests. SKIPPED unless real keys are present in the environment (never run in CI without secrets)."""
import os
import pytest
import ai_service as ai

KEYS = ai.available_providers()

@pytest.mark.skipif(not KEYS["gemini"], reason="GEMINI_API_KEY not set - live Gemini test not run")
def test_live_gemini():
    c, r = ai.process_inquiry_ai("What time do you open on Saturday?", "Live Test", provider="gemini")
    assert c["engine"].startswith("gemini"), c["safety_notes"]; assert not ai.check_response_safety(r)

@pytest.mark.skipif(not KEYS["openai"], reason="OPENAI_API_KEY not set - live OpenAI test not run")
def test_live_openai():
    c, r = ai.process_inquiry_ai("What time do you open on Saturday?", "Live Test", provider="openai")
    assert c["engine"].startswith("openai"), c["safety_notes"]; assert not ai.check_response_safety(r)

@pytest.mark.skipif(not (KEYS["gemini"] or KEYS["openai"]), reason="no live key set")
def test_live_urgent_is_never_model_written():
    c, r = ai.process_inquiry_ai("I have severe chest pain and can't breathe", "Live Test")
    assert c["is_urgent"] and "112" in r
