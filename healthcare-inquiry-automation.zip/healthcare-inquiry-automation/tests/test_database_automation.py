import datetime, sqlite3, threading
import pytest
import automation as au
import config, database as db
from conftest import make_record

def days(n): return (datetime.datetime.now() + datetime.timedelta(days=n)).strftime("%Y-%m-%d")

# ---------- persistence
def test_insert_and_read_back():
    eid = make_record(patient_name="  Asha  ", patient_email="ASHA@Example.com")
    r = db.get_inquiry(eid)
    assert r["patient_name"] == "Asha" and r["patient_email"] == "asha@example.com" and r["source"] == "web_form"

def test_data_persists_across_connections():
    eid = make_record(); db.init_db(); assert db.get_inquiry(eid) is not None

def test_status_updates_and_validation():
    eid = make_record()
    assert db.update_record(eid, "Resolved", "Completed", "done")
    r = db.get_inquiry(eid); assert (r["enquiry_status"], r["follow_up_status"], r["staff_notes"]) == ("Resolved", "Completed", "done")
    with pytest.raises(ValueError): db.update_inquiry_status(eid, "Nonsense")
    with pytest.raises(ValueError): db.update_follow_up_status(eid, "Nonsense")

def test_duplicate_submission_detection():
    make_record(patient_email="d@example.com", original_message="same message here")
    assert db.find_recent_duplicate("D@example.com", "same message here")
    assert db.find_recent_duplicate("other@example.com", "same message here") is None

def test_migration_preserves_existing_rows(tmp_path, monkeypatch):
    legacy = tmp_path / "legacy.db"
    c = sqlite3.connect(legacy)
    c.executescript("""CREATE TABLE inquiries (id INTEGER PRIMARY KEY AUTOINCREMENT, enquiry_id TEXT UNIQUE NOT NULL, patient_name TEXT NOT NULL,
      patient_email TEXT NOT NULL, original_category TEXT NOT NULL, ai_category TEXT NOT NULL, confidence REAL NOT NULL, explanation TEXT NOT NULL,
      is_urgent INTEGER NOT NULL DEFAULT 0, original_message TEXT NOT NULL, generated_response TEXT NOT NULL, submission_timestamp TEXT NOT NULL,
      enquiry_status TEXT NOT NULL DEFAULT 'Pending Review', follow_up_status TEXT NOT NULL DEFAULT 'Follow-up Required', follow_up_due_date TEXT NOT NULL,
      last_notification_sent_at TEXT, notification_count INTEGER NOT NULL DEFAULT 0, staff_notes TEXT DEFAULT '', updated_at TEXT NOT NULL);
      INSERT INTO inquiries (enquiry_id,patient_name,patient_email,original_category,ai_category,confidence,explanation,original_message,generated_response,
      submission_timestamp,follow_up_due_date,staff_notes,updated_at) VALUES ('OLD-1','Old Patient','o@example.com','Other','Other',.5,'e','old msg','old reply',
      '2026-01-01T10:00:00','2026-01-03','Seeded synthetic record for demo','2026-01-01T10:00:00');""")
    c.commit(); c.close()
    monkeypatch.setattr(config, "DB_PATH", legacy)
    db.init_db(); db.init_db()  # idempotent
    r = db.get_inquiry("OLD-1")
    assert r["patient_name"] == "Old Patient" and r["source"] == "demo_seed" and r["ai_engine"] == "unknown"

def test_delete_demo_only_touches_demo_rows():
    real = make_record(); make_record(source="demo_seed"); make_record(source="demo_seed")
    assert db.delete_demo_records() == 2 and db.count_inquiries() == 1 and db.get_inquiry(real)

# ---------- eligibility rules
def inq(**o):
    base = dict(enquiry_status="Pending Review", follow_up_status="Follow-up Required", is_urgent=0, follow_up_due_date=days(-1),
                notification_count=0, last_notification_sent_at=None)
    base.update(o); return base

def test_eligibility_rules():
    assert au.evaluate_follow_up_eligibility(inq())[0]
    assert not au.evaluate_follow_up_eligibility(inq(follow_up_due_date=days(2)))[0]
    assert not au.evaluate_follow_up_eligibility(inq(enquiry_status="Resolved"))[0]
    assert not au.evaluate_follow_up_eligibility(inq(follow_up_status="Completed"))[0]
    assert not au.evaluate_follow_up_eligibility(inq(is_urgent=1))[0]
    assert not au.evaluate_follow_up_eligibility(inq(notification_count=config.MAX_FOLLOWUP_ATTEMPTS))[0]
    recent = (datetime.datetime.now() - datetime.timedelta(hours=2)).isoformat()
    ok, why = au.evaluate_follow_up_eligibility(inq(last_notification_sent_at=recent)); assert not ok and "Cooldown" in why

# ---------- sweep behaviour
def test_sweep_sends_once_then_prevents_duplicates():
    eid = make_record()
    first = au.run_follow_up_automation_cycle(); second = au.run_follow_up_automation_cycle()
    assert first["dispatched_count"] == 1 and second["dispatched_count"] == 0
    logs = db.get_notification_logs_df(eid)
    assert len(logs) == 1 and logs.iloc[0]["status"] == "Simulated (not sent)"
    r = db.get_inquiry(eid); assert r["follow_up_status"] == "Follow-up Sent" and r["notification_count"] == 1

def test_future_and_resolved_not_sent():
    make_record(follow_up_due_date=days(3)); make_record(enquiry_status="Resolved")
    assert au.run_follow_up_automation_cycle()["dispatched_count"] == 0

def test_urgent_escalated_not_reminded():
    eid = make_record(is_urgent=True, patient_name="Urgent Person")
    res = au.run_follow_up_automation_cycle()
    assert res["dispatched_count"] == 0 and res["escalated_count"] == 1
    assert db.get_notification_logs_df(eid).empty
    assert any(a["status"] == "ESCALATED" and a["enquiry_id"] == eid for a in res["actions"])

def test_retry_ceiling_flags_manual_followup(monkeypatch):
    eid = make_record(notification_count=config.MAX_FOLLOWUP_ATTEMPTS,
                      last_notification_sent_at=(datetime.datetime.now() - datetime.timedelta(days=3)).isoformat(), follow_up_status="Follow-up Sent")
    res = au.run_follow_up_automation_cycle()
    assert res["dispatched_count"] == 0 and db.get_inquiry(eid)["follow_up_status"] == "Manual Follow-up Needed"
    assert au.run_follow_up_automation_cycle()["escalated_count"] == 0  # not re-escalated every sweep

def test_attempt_ceiling_enforced_in_db_layer():
    eid = make_record(); sent = 0
    for _ in range(6):
        if au.dispatch_notification_safe(eid, "t@example.com", "s", "b", cooldown_hours=0): sent += 1
    assert sent == config.MAX_FOLLOWUP_ATTEMPTS and db.get_inquiry(eid)["notification_count"] == sent

def test_concurrent_claims_send_exactly_one():
    eid = make_record(); results = []
    def go(): results.append(au.dispatch_notification_safe(eid, "t@example.com", "s", "b"))
    ts = [threading.Thread(target=go) for _ in range(8)]
    [t.start() for t in ts]; [t.join() for t in ts]
    assert sum(1 for r in results if r) == 1 and len(db.get_notification_logs_df(eid)) == 1

def test_resolved_record_cannot_be_claimed():
    eid = make_record(enquiry_status="Resolved"); assert au.dispatch_notification_safe(eid, "t@example.com", "s", "b") is None

def test_outbox_file_written():
    make_record(); au.run_follow_up_automation_cycle()
    assert "Simulated" in config.NOTIFICATIONS_LOG_PATH.read_text(encoding="utf-8")

# ---------- dashboard numbers come from rows
def test_dashboard_summary_matches_rows():
    make_record(); make_record(enquiry_status="Resolved", follow_up_status="Completed"); make_record(is_urgent=True)
    make_record(enquiry_status="Under Investigation"); make_record(source="demo_seed", follow_up_due_date=days(5))
    s = db.get_dashboard_summary(); df = db.get_all_inquiries_df()
    assert s["total_enquiries"] == len(df) == 5
    assert s["resolved_enquiries"] == 1 and s["pending_enquiries"] == 3 and s["under_investigation"] == 1
    assert s["urgent_flags"] == 1 and s["urgent_open"] == 1 and s["demo_records"] == 1
    assert s["follow_ups_due"] == 2 and s["follow_ups_upcoming"] == 1   # plain + under-investigation due; urgent and resolved excluded
    assert s["follow_ups_completed"] == 1

def test_empty_db_summary_is_zero_not_fabricated():
    s = db.get_dashboard_summary(); assert s["total_enquiries"] == 0 and s["avg_confidence"] is None

def test_activity_feed_is_real():
    make_record(patient_name="Feed Person"); au.run_follow_up_automation_cycle()
    texts = [a["text"] for a in db.get_recent_activity(10)]
    assert any("Feed Person" in t for t in texts) and any("logged for" in t for t in texts)

# ---------- seeding
def test_seed_idempotent_and_tagged():
    from generate_demo_data import seed_synthetic_data
    n = seed_synthetic_data(); assert n > 0 and seed_synthetic_data() == 0
    df = db.get_all_inquiries_df(); assert set(df["source"]) == {"demo_seed"}
    assert all(e.endswith("@example.com") for e in df["patient_email"])
    assert df[df["is_urgent"] == 1].shape[0] >= 1
    assert seed_synthetic_data(force_reseed=True) == n and db.count_inquiries() == n
