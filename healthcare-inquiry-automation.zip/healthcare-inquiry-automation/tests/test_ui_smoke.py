"""Streamlit AppTest: each page renders without an exception, and key flows work (isolated DB)."""
import pytest
from pathlib import Path
from streamlit.testing.v1 import AppTest
from generate_demo_data import seed_synthetic_data
import database as db

ROOT = Path(__file__).resolve().parent.parent


def V(name):
    return str(ROOT / "views" / f"{name}.py")


PAGES = ["dashboard", "inquiries", "new_enquiry", "classification", "followups", "analytics", "settings"]

@pytest.mark.parametrize("empty", [True, False], ids=["empty-db", "seeded-db"])
@pytest.mark.parametrize("page", PAGES)
def test_page_renders(page, empty):
    if not empty: seed_synthetic_data()
    at = AppTest.from_file(V(page), default_timeout=30).run()
    assert not at.exception, [e.value for e in at.exception]

def test_form_submission_end_to_end():
    at = AppTest.from_file(V("new_enquiry"), default_timeout=30).run()
    at.text_input(key="f_name").set_value("Asha Verma"); at.text_input(key="f_email").set_value("asha@example.com")
    at.selectbox(key="f_cat").set_value("Clinic timings"); at.text_area(key="f_msg").set_value("Are you open on Saturday and until what time?")
    at.button[-1].click().run()
    assert not at.exception and db.count_inquiries() == 1
    r = db.get_all_inquiries_df().iloc[0]
    assert r["ai_category"] == "Clinic timings" and r["is_urgent"] == 0 and r["source"] == "web_form"

def test_form_rejects_invalid_and_saves_nothing():
    at = AppTest.from_file(V("new_enquiry"), default_timeout=30).run()
    at.text_input(key="f_name").set_value("A"); at.text_input(key="f_email").set_value("bad"); at.text_area(key="f_msg").set_value("tiny")
    at.button[-1].click().run()
    assert not at.exception and db.count_inquiries() == 0

def test_urgent_form_submission_flags_and_uses_112():
    at = AppTest.from_file(V("new_enquiry"), default_timeout=30).run()
    at.text_input(key="f_name").set_value("Imran Khan"); at.text_input(key="f_email").set_value("imran@example.com")
    at.text_area(key="f_msg").set_value("Severe chest pain and I cannot breathe, please help")
    at.button[-1].click().run()
    r = db.get_all_inquiries_df().iloc[0]
    assert r["is_urgent"] == 1 and "112" in r["generated_response"] and "911" not in r["generated_response"]

def test_status_update_from_inquiries_page():
    seed_synthetic_data(); eid = db.get_all_inquiries_df().iloc[0]["enquiry_id"]
    at = AppTest.from_file(V("inquiries"), default_timeout=30).run()
    form_buttons = [b for b in at.button if b.label == "Save changes"]
    assert form_buttons, "Save button should exist"
