import json, threading, urllib.request, urllib.error
import pytest
from sweep_api import make_server
from conftest import make_record

@pytest.fixture
def server(monkeypatch):
    srv = make_server("127.0.0.1", 0); port = srv.server_address[1]
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    yield f"http://127.0.0.1:{port}"
    srv.shutdown(); srv.server_close()

def call(url, method="GET", token=None):
    req = urllib.request.Request(url, method=method, data=b"" if method == "POST" else None)
    if token: req.add_header("X-Sweep-Token", token)
    try:
        with urllib.request.urlopen(req) as r: return r.status, json.loads(r.read())
    except urllib.error.HTTPError as e: return e.code, json.loads(e.read())

def test_health(server): assert call(server + "/health") == (200, {"status": "ok", "service": "followup-sweep-api"})
def test_unknown_path(server): assert call(server + "/nope")[0] == 404
def test_refuses_when_token_not_configured(server): assert call(server + "/api/followup/sweep", "POST", "x")[0] == 503
def test_rejects_wrong_or_missing_token(server, monkeypatch):
    monkeypatch.setenv("SWEEP_API_TOKEN", "secret-token")
    assert call(server + "/api/followup/sweep", "POST")[0] == 401
    assert call(server + "/api/followup/sweep", "POST", "wrong")[0] == 401
def test_sweep_returns_n8n_shape_and_is_idempotent(server, monkeypatch):
    monkeypatch.setenv("SWEEP_API_TOKEN", "secret-token"); make_record(); make_record(is_urgent=True)
    code, body = call(server + "/api/followup/sweep", "POST", "secret-token")
    assert code == 200 and body["delivery_mode"] == "simulated"
    assert body["summary"]["dispatched"] == 1 and body["summary"]["escalated"] == 1
    assert call(server + "/api/followup/sweep", "POST", "secret-token")[1]["summary"]["dispatched"] == 0
def test_get_on_sweep_not_allowed(server): assert call(server + "/api/followup/sweep")[0] == 404
