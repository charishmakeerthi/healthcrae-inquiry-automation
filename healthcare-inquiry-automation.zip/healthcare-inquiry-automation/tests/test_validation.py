import pytest
from validation import validate_enquiry_form as v

OK = ("Asha Verma", "asha@example.com", "Do you offer vaccines for children?")

def test_valid():
    assert v(*OK)[0]

@pytest.mark.parametrize("email", ["", "plain", "a@b", "a@@b.com", "a..b@c.com", "a b@c.com", "a@b.c", "x" * 250 + "@a.com"])
def test_bad_emails(email):
    ok, msg = v(OK[0], email, OK[2]); assert not ok and "email" in msg.lower()

def test_name_rules():
    assert not v("A", OK[1], OK[2])[0]
    assert not v("N" * 101, OK[1], OK[2])[0]
    assert not v("Bad\x00Name", OK[1], OK[2])[0]

def test_message_rules():
    assert not v(OK[0], OK[1], "short")[0]
    assert not v(OK[0], OK[1], "m" * 3001)[0]

def test_category_must_be_known():
    assert not v(*OK, category="Hacking")[0]
