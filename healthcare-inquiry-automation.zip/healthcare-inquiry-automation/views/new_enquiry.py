"""New Enquiry - validated intake form -> AI triage -> persisted to SQLite."""

import datetime

import streamlit as st

from ai_service import process_inquiry_ai
from config import CATEGORIES, EMERGENCY_NUMBER
from database import find_recent_duplicate, insert_inquiry
from ui_components import banner, card_header, esc, esc_multiline, page_header, pill, render, spacer
from validation import MAX_MESSAGE, validate_enquiry_form

page_header("New Enquiry", "Capture a patient enquiry. It is triaged by AI and saved to the database")

banner("critical", f"<b>Medical emergency?</b> If the patient has chest pain, trouble breathing, heavy bleeding, stroke signs or "
                   f"thoughts of self-harm, tell them to call <b>{EMERGENCY_NUMBER}</b> (India's emergency number) or go to the nearest "
                   "hospital emergency department. Do not wait for a reply from this form.")

PRESETS = {
    "Routine booking": ("Asha Verma", "asha.verma@example.com", "Appointment booking",
                        "Hello, I would like to book a routine health check with Dr. Anita Rao next Tuesday afternoon."),
    "Saturday timings": ("Ravi Kumar", "ravi.kumar@example.com", "Clinic timings",
                         "Are you open on Saturdays and what time do you close?"),
    "Lab and fees": ("Latha Rao", "latha.rao@example.com", "Available services",
                     "Do you do lipid profile blood tests and what is the approximate cost?"),
    "Urgent symptoms": ("Imran Khan", "imran.khan@example.com", "General enquiry",
                        "I have sudden crushing chest pain and shortness of breath right now. Can a doctor see me immediately?"),
}


def _load(key: str) -> None:
    n, e, c, m = PRESETS[key]
    st.session_state.update(f_name=n, f_email=e, f_cat=c, f_msg=m)
    st.session_state.pop("last_result", None)


with st.container(border=True):
    card_header("Synthetic examples", "One click fills the form with fictional data for demonstration")
    cols = st.columns(len(PRESETS))
    for col, name in zip(cols, PRESETS):
        col.button(name, key=f"preset_{name}", on_click=_load, args=(name,), width="stretch")
spacer(16)

with st.form("enquiry_form", clear_on_submit=False):
    card_header("Enquiry details", "Fields marked * are required")
    a, b = st.columns(2)
    name = a.text_input("Patient name *", key="f_name", placeholder="e.g. Asha Verma", max_chars=100)
    email = b.text_input("Email *", key="f_email", placeholder="name@example.com", max_chars=254)
    category = st.selectbox("Category *", CATEGORIES, key="f_cat")
    message = st.text_area("Message *", key="f_msg", height=140, max_chars=MAX_MESSAGE,
                           placeholder="Describe the question or request (10 to 3,000 characters)")
    submitted = st.form_submit_button("Submit and run AI triage", type="primary", width="stretch")

if submitted:
    ok, error = validate_enquiry_form(name, email, message, category)
    if not ok:
        banner("critical", esc(error))
    elif (dup := find_recent_duplicate(email, message)):
        banner("warning", f"This looks like a duplicate of <b>{esc(dup)}</b> submitted in the last 10 minutes, so it was not saved again.")
    else:
        with st.spinner("Classifying the enquiry and preparing a reply..."):
            cls, reply = process_inquiry_ai(message, name, category, provider=st.session_state.get("ai_provider", "auto"),
                                            custom_gemini_key=st.session_state.get("gemini_api_key") or None,
                                            custom_openai_key=st.session_state.get("openai_api_key") or None)
            ref = insert_inquiry({
                "patient_name": name, "patient_email": email, "original_category": category, "ai_category": cls["category"],
                "confidence": cls["confidence"], "explanation": cls["explanation"], "is_urgent": cls["is_urgent"],
                "original_message": message, "generated_response": reply,
                "submission_timestamp": datetime.datetime.now().isoformat(), "ai_engine": cls["engine"],
                "safety_notes": ", ".join(cls.get("safety_notes", [])),
            })
        st.session_state["last_result"] = (ref, cls, reply)

if "last_result" in st.session_state:
    ref, cls, reply = st.session_state["last_result"]
    spacer(16)
    banner("success", f"Enquiry saved. Reference <b>{esc(ref)}</b>", "check")
    with st.container(border=True):
        card_header("AI triage result")
        urgent = pill("Urgent - staff alerted", "critical") if cls["is_urgent"] else pill("Standard priority", "success")
        render(f'''{pill(cls["category"], "primary")} {pill(f"Confidence {round(cls['confidence'] * 100)}%", "neutral")}
                   {urgent} {pill(cls["engine"], "neutral")}
                   <div class="field-label">Rationale</div><div class="textbox">{esc(cls["explanation"])}</div>''')
        if cls.get("safety_notes"):
            render(f'<div class="field-label">Safety and fallback notes</div><div class="textbox">{esc("; ".join(cls["safety_notes"]))}</div>')
        render(f'<div class="field-label">Reply to the patient</div><div class="textbox">{esc_multiline(reply)}</div>')
