"""Dashboard - every number here is computed from the SQLite database."""

import pandas as pd
import streamlit as st

from database import get_all_inquiries_df, get_dashboard_summary, get_recent_activity
from ui_components import (banner, card_header, donut_chart, empty_state, esc, fmt_ts, inquiries_table, kpi_card,
                           page_header, pill, render, show_flash, spacer, trend_chart)

head_l, head_r = st.columns([4, 1.2], vertical_alignment="bottom")
with head_l:
    page_header("Dashboard", "Live view of patient enquiries, urgent cases and follow-ups")
with head_r:
    if st.button("New enquiry", type="primary", icon=":material/add:", width="stretch"):
        st.switch_page("views/new_enquiry.py")
show_flash()

s = get_dashboard_summary()
df = get_all_inquiries_df()

if s["total_enquiries"] == 0:
    with st.container(border=True):
        empty_state("No enquiries yet", "Submit one from 'New Enquiry', or load synthetic demo data from Settings > Data.")
    st.stop()

if s["urgent_open"]:
    banner("critical", f"<b>{s['urgent_open']} urgent enquiry(s) are open.</b> These were flagged for a human call-back "
                       "and never receive automated reminders. Review them in Patient Inquiries.")

rate = round(100 * s["resolved_enquiries"] / s["total_enquiries"])
k = st.columns(4)
with k[0]:
    kpi_card("Total enquiries", s["total_enquiries"], "inbox", "primary", f"{s['demo_records']} synthetic demo, {s['total_enquiries'] - s['demo_records']} from the form")
with k[1]:
    kpi_card("Pending", s["pending_enquiries"], "clock", "warning", f"{s['under_investigation']} more under investigation")
with k[2]:
    kpi_card("Resolved", s["resolved_enquiries"], "check", "success", f"{rate}% of all enquiries")
with k[3]:
    kpi_card("Urgent", s["urgent_flags"], "alert", "critical" if s["urgent_open"] else "neutral", f"{s['urgent_open']} still open")
spacer(16)

c1, c2 = st.columns([2, 1])
with c1:
    with st.container(border=True):
        card_header("Enquiries per day", "Last 14 days, from stored submission timestamps")
        st.altair_chart(trend_chart(df), width="stretch")
with c2:
    with st.container(border=True):
        card_header("Category mix", "As classified")
        st.altair_chart(donut_chart(df), width="stretch")
spacer(16)

c3, c4 = st.columns([2, 1])
with c3:
    with st.container(border=True):
        card_header("Recent enquiries", "Latest 8 submissions")
        render(inquiries_table(df.head(8)))
with c4:
    with st.container(border=True):
        card_header("Follow-up overview", "Automated reminders are simulated")
        rows = [("Due now or overdue", s["follow_ups_due"], "warning" if s["follow_ups_due"] else "neutral"),
                ("Upcoming", s["follow_ups_upcoming"], "primary"),
                ("Reminders logged", s["notifications_logged"], "neutral"),
                ("Needs manual follow-up", s["follow_ups_manual"], "critical" if s["follow_ups_manual"] else "neutral"),
                ("Completed", s["follow_ups_completed"], "success")]
        render("".join(f'<div class="stat-row"><span>{esc(a)}</span>{pill(str(b), t)}</div>' for a, b, t in rows))
    spacer(16)
    with st.container(border=True):
        card_header("Recent activity", "From enquiries and notification logs")
        colors = {"urgent": "#DC2626", "enquiry": "#2563EB", "notification": "#16A34A"}
        feed = get_recent_activity(6)
        render("".join(f'<div class="feed-item"><span class="dot" style="background:{colors[i["kind"]]}"></span>'
                       f'<div>{esc(i["text"])}<div class="feed-time">{fmt_ts(i["ts"])}</div></div></div>' for i in feed))
