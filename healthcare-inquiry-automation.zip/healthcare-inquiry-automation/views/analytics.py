"""Analytics - all charts and figures derived from stored records."""

import pandas as pd
import streamlit as st

from database import get_all_inquiries_df
from ui_components import (PALETTE, bar_chart, card_header, daily_counts, donut_chart, empty_state, kpi_card, page_header, spacer,
                           trend_chart)

page_header("Analytics", "Volume, category mix, statuses and AI engine usage")
df = get_all_inquiries_df()
if df.empty:
    with st.container(border=True):
        empty_state("No data yet", "Analytics appear once enquiries exist.")
    st.stop()

total = len(df)
resolved = int((df["enquiry_status"] == "Resolved").sum())
urgent = int(df["is_urgent"].sum())
k = st.columns(4)
with k[0]:
    kpi_card("Resolution rate", f"{round(100 * resolved / total)}%", "check", "success", f"{resolved} of {total} resolved")
with k[1]:
    kpi_card("Urgent share", f"{round(100 * urgent / total)}%", "alert", "critical" if urgent else "neutral", f"{urgent} of {total} flagged")
with k[2]:
    kpi_card("Avg. confidence", f"{round(100 * df['confidence'].mean())}%", "activity", "primary", "Rule-based scores are heuristic")
with k[3]:
    kpi_card("Reminders per enquiry", f"{df['notification_count'].mean():.1f}", "send", "neutral", "Mean automated attempts")
spacer(16)

c1, c2 = st.columns([2, 1])
with c1:
    with st.container(border=True):
        card_header("Enquiries per day", "Last 30 days")
        st.altair_chart(trend_chart(df, days=30, height=260), width="stretch")
with c2:
    with st.container(border=True):
        card_header("Category mix")
        st.altair_chart(donut_chart(df, height=260), width="stretch")
spacer(16)

c3, c4, c5 = st.columns(3)
with c3:
    with st.container(border=True):
        card_header("Enquiry status")
        d = df["enquiry_status"].value_counts().rename_axis("Status").reset_index(name="Count")
        st.altair_chart(bar_chart(d, "Status", "Count"), width="stretch")
with c4:
    with st.container(border=True):
        card_header("Follow-up status")
        d = df["follow_up_status"].value_counts().rename_axis("Status").reset_index(name="Count")
        st.altair_chart(bar_chart(d, "Status", "Count", "#0EA5E9"), width="stretch")
with c5:
    with st.container(border=True):
        card_header("AI engine used")
        d = df["ai_engine"].value_counts().rename_axis("Engine").reset_index(name="Count")
        st.altair_chart(bar_chart(d, "Engine", "Count", "#16A34A"), width="stretch")
spacer(16)

with st.container(border=True):
    card_header("By category", "Counts, urgent cases and mean confidence")
    t = df.groupby("ai_category").agg(Enquiries=("enquiry_id", "count"), Urgent=("is_urgent", "sum"),
                                      Resolved=("enquiry_status", lambda s: int((s == "Resolved").sum())),
                                      Avg_confidence=("confidence", "mean")).reset_index()
    t["Avg_confidence"] = (t["Avg_confidence"] * 100).round().astype(int).astype(str) + "%"
    st.dataframe(t.rename(columns={"ai_category": "Category", "Avg_confidence": "Avg confidence"}), hide_index=True, width="stretch")
