"""Settings - knowledge base, AI engine selection, data management."""

import streamlit as st

from ai_service import available_providers, process_inquiry_ai
from config import CLINIC_KNOWLEDGE_BASE as KB, DB_PATH, DEMO_NOTICE, EMERGENCY_NUMBER, GEMINI_MODEL, OPENAI_MODEL
from database import count_inquiries, delete_demo_records, get_dashboard_summary
from generate_demo_data import seed_synthetic_data
from ui_components import banner, card_header, esc, flash, page_header, pill, render, show_flash, spacer

page_header("Settings", "Approved knowledge base, AI engine and data")
show_flash()
tab_kb, tab_ai, tab_data = st.tabs(["Knowledge base", "AI engine", "Data"])

with tab_kb:
    banner("warning", f"<b>Demo content.</b> {esc(KB['demo_notice'])} Replace every value with clinic-approved facts before real use. "
                      f"The emergency instruction uses India's national number {EMERGENCY_NUMBER}.", "alert")
    a, b = st.columns(2)
    with a:
        with st.container(border=True):
            card_header("Clinic")
            h = KB["operating_hours"]
            render(f'''<div class="stat-row"><span>Name</span><b style="font-size:.86rem">{esc(KB["clinic_name"])}</b></div>
              <div class="stat-row"><span>Address</span><span>{esc(KB["address"])}</span></div>
              <div class="stat-row"><span>Phone</span><span>{esc(KB["phone"])}</span></div>
              <div class="stat-row"><span>Email</span><span>{esc(KB["email"])}</span></div>
              <div class="stat-row"><span>Mon - Fri</span><span>{esc(h["Monday - Friday"])}</span></div>
              <div class="stat-row"><span>Saturday</span><span>{esc(h["Saturday"])}</span></div>
              <div class="stat-row"><span>Sunday</span><span>{esc(h["Sunday"])}</span></div>''')
        spacer(16)
        with st.container(border=True):
            card_header("Practitioners (fictional)")
            render("".join(f'<div class="stat-row"><b style="font-size:.86rem">{esc(d["name"])}</b><span>{esc(d["specialty"])}</span></div>' for d in KB["practitioners"]))
    with b:
        with st.container(border=True):
            card_header("Services and demo fees")
            render("".join(f'<div class="stat-row" style="flex-direction:column;align-items:flex-start;gap:2px"><b style="font-size:.88rem">{esc(s["name"])} '
                           f'<span style="font-weight:500;color:#64748B">- {esc(s["fee_range"])}</span></b><span style="color:#64748B">{esc(s["description"])}</span></div>'
                           for s in KB["approved_services"]))
        spacer(16)
        with st.container(border=True):
            card_header("Policies")
            p = KB["appointment_policy"]
            render(f'<div class="stat-row"><span>Payment</span><span style="text-align:right;max-width:70%">{esc(KB["payment_and_insurance"])}</span></div>'
                   f'<div class="stat-row"><span>Booking</span><span style="text-align:right;max-width:70%">{esc(p["booking_advance"])}</span></div>'
                   f'<div class="stat-row"><span>Cancellation</span><span style="text-align:right;max-width:70%">{esc(p["cancellation"])}</span></div>'
                   f'<div class="stat-row"><span>Walk-ins</span><span style="text-align:right;max-width:70%">{esc(p["walk_ins"])}</span></div>')

with tab_ai:
    LABELS = {"auto": "Auto: Gemini, then OpenAI, then offline rules", "gemini": "Gemini only (falls back to rules)",
              "openai": "OpenAI only (falls back to rules)", "offline": "Offline rules only (no external calls)"}
    with st.container(border=True):
        card_header("Engine", f"Models: {GEMINI_MODEL} and {OPENAI_MODEL} (override with GEMINI_MODEL / OPENAI_MODEL)")
        st.selectbox("Provider", list(LABELS), format_func=LABELS.get, key="ai_provider")
        keys = available_providers(st.session_state.get("gemini_api_key"), st.session_state.get("openai_api_key"))
        render(f'Gemini key: {pill("configured", "success") if keys["gemini"] else pill("not set", "neutral")} &nbsp; '
               f'OpenAI key: {pill("configured", "success") if keys["openai"] else pill("not set", "neutral")}')
        st.caption("Preferred: put keys in a local .env file (see .env.example). Keys pasted below live only in this browser session "
                   "and are never written to disk or the database.")
        g = st.text_input("Gemini API key (session only)", type="password", key="gemini_api_key")
        o = st.text_input("OpenAI API key (session only)", type="password", key="openai_api_key")
    spacer(16)
    with st.container(border=True):
        card_header("Test the selected engine", "Sends one harmless sample message and shows which engine actually answered")
        if st.button("Run engine test"):
            cls, _ = process_inquiry_ai("What time do you open on Saturday?", "Test Patient",
                                        provider=st.session_state.get("ai_provider", "auto"),
                                        custom_gemini_key=g or None, custom_openai_key=o or None)
            used = cls["engine"]
            if used.startswith(("gemini", "openai")):
                banner("success", f"Live call succeeded using <b>{esc(used)}</b>.", "check")
            else:
                banner("warning", "No live model answered, so the rule-based fallback was used. Notes: "
                                  f"<b>{esc('; '.join(cls.get('safety_notes', [])) or 'no key configured or offline mode selected')}</b>")

with tab_data:
    s = get_dashboard_summary()
    with st.container(border=True):
        card_header("Database", f"SQLite file: {DB_PATH.name} (WAL mode)")
        render(f'<div class="stat-row"><span>Total enquiries</span><b>{s["total_enquiries"]}</b></div>'
               f'<div class="stat-row"><span>Synthetic demo records</span><b>{s["demo_records"]}</b></div>'
               f'<div class="stat-row"><span>Submitted through the form</span><b>{s["total_enquiries"] - s["demo_records"]}</b></div>'
               f'<div class="stat-row"><span>Notification logs</span><b>{s["notifications_logged"]}</b></div>')
        st.caption(DEMO_NOTICE)
    spacer(16)
    with st.container(border=True):
        card_header("Demo data", "Load or remove synthetic records. Real submissions are never touched")
        c1, c2 = st.columns(2)
        if c1.button("Load synthetic demo data", width="stretch"):
            n = seed_synthetic_data()
            flash(f"Loaded {n} synthetic records." if n else "Demo data is already loaded.")
            st.rerun()
        confirm = c2.checkbox("I understand this deletes only demo records")
        if c2.button("Delete demo records", disabled=not confirm, width="stretch"):
            flash(f"Deleted {delete_demo_records()} demo records.")
            st.rerun()
