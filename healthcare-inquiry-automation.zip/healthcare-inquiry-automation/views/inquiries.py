"""Patient Inquiries - search, filter, inspect, update status, trigger a manual (simulated) follow-up."""

import streamlit as st

from automation import dispatch_notification_safe, generate_follow_up_template
from config import CATEGORIES, ENQUIRY_STATUSES, FOLLOW_UP_STATUSES
from database import get_all_inquiries_df, get_inquiry, get_notification_logs_df, update_record
from ui_components import (banner, card_header, empty_state, esc, esc_multiline, flash, fmt_ts, page_header, pill,
                           render, show_flash, spacer)

page_header("Patient Inquiries", "Search and filter enquiries, review the AI result, and update the record")
show_flash()

df = get_all_inquiries_df()
if df.empty:
    with st.container(border=True):
        empty_state("No enquiries yet", "New submissions will appear here.")
    st.stop()

with st.container(border=True):
    f1, f2, f3, f4 = st.columns([1, 1, 1, 1.6])
    status_f = f1.selectbox("Status", ["All"] + ENQUIRY_STATUSES)
    cat_f = f2.selectbox("Category", ["All"] + CATEGORIES)
    prio_f = f3.selectbox("Priority", ["All", "Urgent only", "Normal only"])
    query = f4.text_input("Search", placeholder="Name, email, reference or message text")

view = df
if status_f != "All":
    view = view[view["enquiry_status"] == status_f]
if cat_f != "All":
    view = view[view["ai_category"] == cat_f]
if prio_f == "Urgent only":
    view = view[view["is_urgent"] == 1]
elif prio_f == "Normal only":
    view = view[view["is_urgent"] == 0]
if query.strip():
    q = query.strip().lower()
    mask = False
    for col in ("patient_name", "patient_email", "original_message", "enquiry_id"):
        mask = mask | view[col].str.lower().str.contains(q, regex=False, na=False)
    view = view[mask]

st.caption(f"Showing {len(view)} of {len(df)} enquiries")
table = view[["enquiry_id", "patient_name", "ai_category", "is_urgent", "enquiry_status", "follow_up_status",
              "follow_up_due_date", "submission_timestamp"]].copy()
table["is_urgent"] = table["is_urgent"].map({1: "Urgent", 0: "Normal"})
table["submission_timestamp"] = table["submission_timestamp"].str[:16].str.replace("T", " ")
st.dataframe(table, hide_index=True, width="stretch", height=min(38 + 35 * max(len(table), 1) + 3, 420),
             column_config={"enquiry_id": "Reference", "patient_name": "Patient", "ai_category": "Category",
                            "is_urgent": "Priority", "enquiry_status": "Status", "follow_up_status": "Follow-up",
                            "follow_up_due_date": "Follow-up due", "submission_timestamp": "Submitted"})
spacer(8)

if view.empty:
    with st.container(border=True):
        empty_state("No matches", "Try clearing a filter or changing the search text.")
    st.stop()

labels = {r.enquiry_id: f"{r.enquiry_id}  |  {r.patient_name}  |  {r.ai_category}" for r in view.itertuples()}
selected = st.selectbox("Open record", list(labels), format_func=labels.get)
rec = get_inquiry(selected)
spacer(4)

left, right = st.columns([1.1, 1])
with left:
    with st.container(border=True):
        if rec["is_urgent"]:
            banner("critical", "<b>Urgent.</b> Possible emergency wording. Call the patient directly; do not rely on automated messages.")
        card_header(rec["patient_name"], f"{rec['patient_email']}  |  submitted {fmt_ts(rec['submission_timestamp'])}")
        render(f'''{pill(rec["ai_category"], "primary")} {pill(f"Confidence {round(rec['confidence'] * 100)}%", "neutral")}
                   {pill("Urgent", "critical") if rec["is_urgent"] else ""} {pill(rec["enquiry_status"])} {pill(rec["follow_up_status"])}
                   <div class="field-label">Patient message</div><div class="textbox">{esc_multiline(rec["original_message"])}</div>
                   <div class="field-label">Classification rationale</div><div class="textbox">{esc(rec["explanation"])}</div>
                   <div class="field-label">Engine</div><div class="sub" style="font-size:0.84rem">{esc(rec["ai_engine"])}</div>''')
        if rec["safety_notes"]:
            render(f'<div class="field-label">Safety notes</div><div class="textbox">{esc(rec["safety_notes"])}</div>')
        render(f'<div class="field-label">Reply stored for this enquiry</div><div class="textbox">{esc_multiline(rec["generated_response"])}</div>')

with right:
    with st.form(f"edit_{selected}"):
        card_header("Update record")
        ns = st.selectbox("Enquiry status", ENQUIRY_STATUSES, index=ENQUIRY_STATUSES.index(rec["enquiry_status"]))
        fs = st.selectbox("Follow-up status", FOLLOW_UP_STATUSES, index=FOLLOW_UP_STATUSES.index(rec["follow_up_status"]))
        notes = st.text_area("Staff notes", value=rec["staff_notes"] or "", height=110)
        b1, b2 = st.columns(2)
        save = b1.form_submit_button("Save changes", type="primary", width="stretch")
        manual = b2.form_submit_button("Log follow-up", width="stretch", disabled=bool(rec["is_urgent"]))
    if rec["is_urgent"]:
        st.caption("Manual follow-up logging is disabled for urgent enquiries - call the patient.")

    if save:
        update_record(selected, ns, fs, notes)
        flash("Record saved.")
        st.rerun()
    if manual:
        tpl = generate_follow_up_template(rec)
        sent = dispatch_notification_safe(selected, rec["patient_email"], tpl["subject"], tpl["body"],
                                          notification_type="Manual Staff Follow-up", max_attempts=None, cooldown_hours=1 / 60)
        flash("Follow-up logged (simulated, nothing was e-mailed)." if sent else
              "Not logged: a reminder was already logged in the last minute, or the record is closed.", "success" if sent else "warning")
        st.rerun()

    with st.container(border=True):
        card_header("Notification history", "Audit trail for this enquiry")
        logs = get_notification_logs_df(selected)
        if logs.empty:
            empty_state("Nothing logged", "No reminders have been logged for this enquiry.")
        else:
            st.dataframe(logs[["timestamp", "notification_type", "status"]], hide_index=True, width="stretch")
