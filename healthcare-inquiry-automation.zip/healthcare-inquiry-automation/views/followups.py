"""Follow-ups - run the automation sweep, see who needs a human, audit the notification log."""

import pandas as pd
import streamlit as st

from automation import run_follow_up_automation_cycle
from config import MAX_FOLLOWUP_ATTEMPTS, NOTIFICATION_COOLDOWN_HOURS
from database import get_all_inquiries_df, get_dashboard_summary, get_notification_logs_df
from ui_components import (banner, card_header, empty_state, esc, flash, kpi_card, page_header, pill, render,
                           show_flash, spacer)

page_header("Follow-ups", "Scheduled reminders with cooldown, attempt limits and an audit trail")
show_flash()
s = get_dashboard_summary()
df = get_all_inquiries_df()

k = st.columns(4)
with k[0]:
    kpi_card("Due now", s["follow_ups_due"], "calendar", "warning" if s["follow_ups_due"] else "neutral", "Awaiting a reminder, due today or earlier")
with k[1]:
    kpi_card("Upcoming", s["follow_ups_upcoming"], "clock", "primary", "Due in the coming days")
with k[2]:
    kpi_card("Reminders logged", s["notifications_logged"], "send", "neutral", "Simulated, none e-mailed")
with k[3]:
    needs = s["follow_ups_manual"] + s["urgent_open"]
    kpi_card("Needs a human", needs, "user", "critical" if needs else "neutral", "Urgent or attempt limit reached")
spacer(16)

left, right = st.columns([1.4, 1])
with left:
    with st.container(border=True):
        card_header("Run follow-up sweep", "Scans open enquiries and applies the rules below")
        render(f'''<div class="stat-row"><span>Only enquiries due today or earlier</span>{pill("Due date", "neutral")}</div>
                   <div class="stat-row"><span>Minimum gap between reminders</span>{pill(f"{NOTIFICATION_COOLDOWN_HOURS} hours", "neutral")}</div>
                   <div class="stat-row"><span>Maximum automated attempts</span>{pill(str(MAX_FOLLOWUP_ATTEMPTS), "neutral")}</div>
                   <div class="stat-row"><span>Urgent enquiries</span>{pill("Escalated to staff, never auto-reminded", "critical")}</div>''')
        banner("info", "<b>Delivery is simulated.</b> Reminders are written to the audit log and an outbox file. "
                       "No e-mail or SMS provider is connected in this build.", "inbox2")
        if st.button("Run sweep now", type="primary", width="stretch"):
            res = run_follow_up_automation_cycle()
            st.session_state["last_sweep"] = res
            flash(f"Sweep finished: {res['dispatched_count']} logged, {res['skipped_count']} skipped, {res['escalated_count']} escalated.")
            st.rerun()
        sweep = st.session_state.get("last_sweep")
        if sweep:
            render(f'<div class="field-label">Last sweep ({esc(sweep["run_timestamp"][:19].replace("T", " "))})</div>')
            st.dataframe(pd.DataFrame(sweep["actions"]), hide_index=True, width="stretch",
                         column_config={"enquiry_id": "Reference", "patient_name": "Patient", "status": "Outcome", "reason": "Reason"})

with right:
    with st.container(border=True):
        card_header("Needs a human", "Urgent cases and records past the attempt limit")
        human = df[((df["is_urgent"] == 1) | (df["follow_up_status"] == "Manual Follow-up Needed")) & (df["enquiry_status"] != "Resolved")]
        if human.empty:
            empty_state("All clear", "No records currently need a manual call-back.")
        else:
            render("".join(f'<div class="stat-row"><span><b>{esc(r.patient_name)}</b><br><span class="sub" style="color:#64748B;font-size:.76rem">{esc(r.enquiry_id)}</span></span>'
                           f'{pill("Urgent", "critical") if r.is_urgent else pill("Attempt limit", "warning")}</div>' for r in human.itertuples()))
    spacer(16)
    with st.container(border=True):
        card_header("n8n scheduling", "Optional external scheduler")
        render('<div class="textbox" style="font-size:.82rem">1. Run <code>python sweep_api.py</code> with <code>SWEEP_API_TOKEN</code> set.<br>'
               "2. Import the workflow JSON into n8n and set the same token as a header credential.<br>3. See the README for the full steps.</div>")
        spacer(8)
        try:
            with open("n8n_healthcare_followup_workflow.json", "rb") as fh:
                st.download_button("Download workflow JSON", fh.read(), "n8n_healthcare_followup_workflow.json", "application/json", width="stretch")
        except OSError:
            st.caption("Workflow file not found.")

spacer(16)
with st.container(border=True):
    card_header("Notification audit log", "Every logged reminder, newest first")
    logs = get_notification_logs_df()
    if logs.empty:
        empty_state("Nothing logged yet", "Run a sweep to create audit records.")
    else:
        st.dataframe(logs[["timestamp", "enquiry_id", "recipient_email", "notification_type", "channel", "status", "subject"]],
                     hide_index=True, width="stretch", height=min(60 + 35 * len(logs), 360))
