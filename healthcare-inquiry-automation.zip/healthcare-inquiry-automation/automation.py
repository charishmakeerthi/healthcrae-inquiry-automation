"""
Follow-up automation engine.

Rules (all enforced in code and covered by tests):
  * Only enquiries that are due (follow_up_due_date <= today) and still open are considered.
  * URGENT enquiries are never sent a generic reminder - they are escalated to a human.
  * A cooldown (default 24h) and an attempt ceiling (default 3) prevent repeat messages.
  * After the ceiling is reached the record is flagged "Manual Follow-up Needed" for staff.
  * Sending is claimed atomically in SQLite, so overlapping sweeps cannot double-send.

IMPORTANT: delivery is SIMULATED. Reminders are written to the audit table and an outbox
log file; no e-mail/SMS provider is connected. See README for how to plug one in (e.g. n8n).
"""

import datetime
from typing import Any, Dict, Optional, Tuple

from config import (
    CLINIC_KNOWLEDGE_BASE,
    MAX_FOLLOWUP_ATTEMPTS,
    NOTIFICATION_COOLDOWN_HOURS,
)
from database import connect, dispatch_follow_up, update_follow_up_status

KB = CLINIC_KNOWLEDGE_BASE
SIMULATED_STATUS = "Simulated (not sent)"
SIMULATED_CHANNEL = "Simulated outbox"


def evaluate_follow_up_eligibility(inquiry: Dict[str, Any], reference_date: Optional[str] = None) -> Tuple[bool, str]:
    """Pure function: decides whether an automated reminder may be sent right now."""
    today = reference_date or datetime.datetime.now().strftime("%Y-%m-%d")

    if inquiry.get("enquiry_status") == "Resolved":
        return False, "Enquiry is already resolved."
    if inquiry.get("follow_up_status") in ("Completed", "Follow-up Not Needed"):
        return False, f"Follow-up status is '{inquiry.get('follow_up_status')}'."
    if inquiry.get("is_urgent"):
        return False, "Urgent enquiry - requires a human call-back, not an automated reminder."
    if inquiry.get("follow_up_status") == "Manual Follow-up Needed":
        return False, "Already flagged for manual follow-up by staff."

    due = inquiry.get("follow_up_due_date")
    if not due or due > today:
        return False, f"Not yet due (due {due}, today {today})."

    if (inquiry.get("notification_count") or 0) >= MAX_FOLLOWUP_ATTEMPTS:
        return False, f"Attempt ceiling reached ({MAX_FOLLOWUP_ATTEMPTS}); staff must follow up manually."

    last = inquiry.get("last_notification_sent_at")
    if last:
        try:
            hours = (datetime.datetime.now() - datetime.datetime.fromisoformat(last)).total_seconds() / 3600
            if hours < NOTIFICATION_COOLDOWN_HOURS:
                return False, f"Cooldown active: last reminder {hours:.1f}h ago (minimum {NOTIFICATION_COOLDOWN_HOURS}h)."
        except ValueError:
            pass
    return True, "Eligible for follow-up reminder."


def generate_follow_up_template(inquiry: Dict[str, Any]) -> Dict[str, str]:
    first = (inquiry["patient_name"] or "there").split()[0]
    enquiry_id = inquiry["enquiry_id"]
    body = (
        f"Dear {first},\n\n"
        f"We are following up on your enquiry to {KB['clinic_name']} on {inquiry['submission_timestamp'][:10]} "
        f"about '{inquiry['ai_category']}' (reference {enquiry_id}).\n\n"
        "- If your question has been answered, no action is needed.\n"
        f"- If you still need an appointment or more information, reply to this message or call {KB['phone']}.\n"
        f"- Opening hours: Monday - Friday {KB['operating_hours']['Monday - Friday']}, "
        f"Saturday {KB['operating_hours']['Saturday']}.\n\n"
        f"Warm regards,\nPatient Coordination Team\n{KB['clinic_name']}\n\n"
        "This is an automated administrative message and not medical advice."
    )
    return {"subject": f"Follow-up on your enquiry ({enquiry_id})", "body": body,
            "recipient_email": inquiry["patient_email"]}


def dispatch_notification_safe(
    enquiry_id: str,
    recipient_email: str,
    subject: str,
    body: str,
    notification_type: str = "Follow-up Reminder",
    channel: str = SIMULATED_CHANNEL,
    max_attempts: Optional[int] = MAX_FOLLOWUP_ATTEMPTS,
    cooldown_hours: float = NOTIFICATION_COOLDOWN_HOURS,
) -> Optional[Dict[str, Any]]:
    """Atomically claim + log a simulated notification. Returns None if the claim was refused."""
    log_id = dispatch_follow_up(
        enquiry_id=enquiry_id, recipient_email=recipient_email, subject=subject,
        payload_preview=body[:200] + ("..." if len(body) > 200 else ""),
        notification_type=notification_type, channel=channel, status=SIMULATED_STATUS,
        cooldown_hours=cooldown_hours, max_attempts=max_attempts,
    )
    if log_id is None:
        return None
    return {"log_id": log_id, "enquiry_id": enquiry_id, "recipient_email": recipient_email,
            "status": SIMULATED_STATUS, "timestamp": datetime.datetime.now().isoformat()}


def run_follow_up_automation_cycle(reference_date: Optional[str] = None) -> Dict[str, Any]:
    """One full sweep over open enquiries. Safe to run repeatedly (idempotent within the cooldown)."""
    today = reference_date or datetime.datetime.now().strftime("%Y-%m-%d")
    result: Dict[str, Any] = {
        "run_timestamp": datetime.datetime.now().isoformat(), "reference_date": today,
        "scanned_total": 0, "eligible_count": 0, "dispatched_count": 0,
        "skipped_count": 0, "escalated_count": 0, "actions": [],
    }
    with connect() as conn:
        rows = [dict(r) for r in conn.execute("SELECT * FROM inquiries WHERE enquiry_status != 'Resolved';")]
    result["scanned_total"] = len(rows)

    def log(inq, status, reason):
        result["actions"].append({"enquiry_id": inq["enquiry_id"], "patient_name": inq["patient_name"],
                                  "status": status, "reason": reason})

    for inq in rows:
        eligible, reason = evaluate_follow_up_eligibility(inq, today)
        if inq.get("is_urgent") and inq.get("follow_up_status") not in ("Completed", "Follow-up Not Needed"):
            result["escalated_count"] += 1
            log(inq, "ESCALATED", "Urgent enquiry - needs staff call-back (no automated reminder sent).")
            continue
        if eligible:
            result["eligible_count"] += 1
            tpl = generate_follow_up_template(inq)
            sent = dispatch_notification_safe(inq["enquiry_id"], tpl["recipient_email"], tpl["subject"], tpl["body"])
            if sent:
                result["dispatched_count"] += 1
                log(inq, "LOGGED (simulated)", "Due, outside cooldown, under attempt ceiling.")
            else:
                result["skipped_count"] += 1
                log(inq, "SKIPPED", "Claim refused at write time (another run got there first).")
        else:
            if reason.startswith("Attempt ceiling"):
                update_follow_up_status(inq["enquiry_id"], "Manual Follow-up Needed")
                result["escalated_count"] += 1
                log(inq, "ESCALATED", reason)
            else:
                result["skipped_count"] += 1
                log(inq, "SKIPPED", reason)
    return result


def sweep_summary_payload() -> Dict[str, Any]:
    """JSON shape consumed by the n8n workflow and by sweep_api.py."""
    cycle = run_follow_up_automation_cycle()
    return {
        "source": "beacon_crest_followup_service",
        "event": "scheduled_followup_sweep",
        "delivery_mode": "simulated",
        "summary": {"scanned": cycle["scanned_total"], "dispatched": cycle["dispatched_count"],
                    "skipped": cycle["skipped_count"], "escalated": cycle["escalated_count"]},
        "details": cycle["actions"],
    }
